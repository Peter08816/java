package com.crankuptheamps.examples;

import com.crankuptheamps.client.*;
import com.crankuptheamps.client.exception.*;

public class EX10AMPSNVFIXBuilderPublisher {

  // The location of the AMPS server.
  private static final String uri_ = "tcp://127.0.0.1:9027/amps/nvfix";
  
  /**
   * main method.
   *
   * @param args -- No command line options read.
   */
  public static void main(String[] args) {

    // Create an HAClient instance named "ConsolePublisher" within a
    // try-with-resources block for automatic resource management
    try (HAClient client = new HAClient("ConsolePublisher");) {
        client.setPublishStore(new MemoryPublishStore(1000));

      // Build the message payload
      // Create a builder with 1024 bytes of initial capacity,
      // using the default 0x01 delimiter.
      NVFIXBuilder builder = new NVFIXBuilder(1024, (byte)1);

      // Add fields to the NVFIXBuilder
      builder.append("test-field", "24");
      builder.append("another", "Here's another field");
      builder.append("data", "1234567890");

      // Create a string for the topic
      String topic = "messages-sow";

      // Initialize a DefaultServerChooser to manage server connections
      DefaultServerChooser sc = new DefaultServerChooser();
      // Add the AMPS server URI to the server chooser
      sc.add(uri_);
      // Set the server chooser for the client
      client.setServerChooser(sc);
      // Connect the client to the AMPS server and log on
      client.connectAndLogon();
      // Print a message indicating a successful connection
      System.out.println("connected..");

      // publish the message, using the overload that takes a byte array and
      // length for the topic and payload.
   
      client.publish(topic.getBytes(), 0, topic.length(), builder.getBytes(), 0, builder.getSize()); 

      client.publishFlush(10000);
    }
    catch (AMPSException e)
    {
      System.err.println(e.getLocalizedMessage());
      e.printStackTrace(System.err);
    }

  }
  }
