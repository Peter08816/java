////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.Field;
import java.io.IOException;
import java.nio.ByteBuffer;

import com.crankuptheamps.client.BlockPublishStore.ByteSequence;

/**
*   MemoryStoreBuffer is a wrapper for a java array that maintains position.
*   In order to do this, MemoryStoreBuffer uses a ByteBuffer.
*/

public class MemoryStoreBuffer implements BlockPublishStore.Buffer
{

    protected ByteBuffer _buffer = null;
    protected Store _store = null;
    
    /**
      * Gets the size of the buffer.
      * @return The size of the buffer.
      * @throws IOException Not thrown from this implementation
      */ 
    public long getSize() throws IOException
    {
        return _buffer==null?0:this._buffer.capacity();
        
    }

    /**
      * Sets the size of the buffer.
      * @param newSize The new size to be assigned to the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public void setSize(long newSize) throws IOException
    {
        if(_buffer==null || newSize > this._buffer.capacity())
        {
            ByteBuffer b2 = ByteBuffer.allocate((int)newSize);
            if(_buffer != null) b2.put(_buffer.array());
            _buffer = b2;
        }
    }

    /**
      * Gets the current position in the buffer.
      * @return The current position in the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public long getPosition() throws IOException
    {
        return _buffer.position();
        
    }

    /**
      * Sets the new current position in the buffer.
      * @param position The new current position to be set in the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public void setPosition(long position) throws IOException
    {
        _buffer.position((int)position);        
    }

    /**
      * Writes the byte in the buffer.
      * @param b The byte to be written in the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public void putByte(byte b) throws IOException
    {
        _buffer.put(b);
    }

    /**
      * Gets the byte from the buffer.
      * @return The byte from the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public byte getByte() throws IOException
    {
        return _buffer.get();
    }

    /**
      * Writes the integer into the buffer.
      * @param i Integer to be placed in the buffer.
      * @throws IOException Not thrown from this implementation
      */
    public void putInt(int i) throws IOException
    {
        _buffer.putInt(i);
    }

    /**
      * Writes the integer into the buffer.
      * @param position The location where the integer is placed in the buffer.
      * @param i Integer to be placed in the buffer.
      * @throws IOException Not thrown from this implementation
      */ 
    public void putInt(long position, int i) throws IOException
    {
        _buffer.putInt((int)position, i);
    }

    /**
     * Gets the integer from the buffer.
     * @return The integer from the buffer.
     * @throws IOException Not thrown from this implementation
     */
    public int getInt() throws IOException
    {
        return _buffer.getInt();
    }

    /**
     * Gets the integer from the buffer. 
     * @param position The position in the buffer where the integer begins.
     * @return The integer from the buffer.
     * @throws IOException Not thrown from this implementation
     */
    public int getInt(long position) throws IOException
    {
        return _buffer.getInt((int)position);
    }

    /**
     * Writes the long to the buffer.
     * @param l The long to write to the buffer.
     * @throws IOException Not thrown from this implementation
     */
    public void putLong(long l) throws IOException
    {
        _buffer.putLong(l);
    }

    /** 
     * Writes the long to the buffer.
     * @param position The position in the buffer where the long should be placed.
     * @param l The long to write in the buffer.
     * @throws IOException Not thrown from this implementation
     */
    public void putLong(long position, long l) throws IOException
    {
        _buffer.putLong((int)position, l);
    }

    /**
     * Gets the long from the buffer.
     * @return The long from the buffer.
     * @throws IOException Not thrown from this implementation 
     */
    public long getLong() throws IOException
    {
        return _buffer.getLong();
    }

    /**
     * Writes a series of bytes at the current position, taken from the specified {@link BlockPublishStore.ByteSequence}.
     * @param bytes The series of bytes to write at the current position.
     * @throws IOException Not thrown from this implementation 
     */ 
    public void putBytes(ByteSequence bytes) throws IOException
    {
        _buffer.put(bytes.array, (int)bytes.offset, (int)bytes.len);
    }

    /**
     * Gets the series of bytes at the current position by placing them into the provided 
     * {@link BlockPublishStore.ByteSequence} object. 
     * @param outBytes The ByteSequence object to be copied.
     * @throws IOException Not thrown from this implementation 
     */ 
    public void getBytes(ByteSequence outBytes) throws IOException
    {
        if(_buffer.hasArray())
        {
            outBytes.array = _buffer.array();
            outBytes.offset = _buffer.position();
            _buffer.position((int)(outBytes.offset + outBytes.len));
        }
        else
        {
            outBytes.array = new byte[(int)outBytes.len];
            outBytes.offset = 0;
            _buffer.get(outBytes.array, 0, (int)outBytes.len);
        }
    }

    /**
     * Writes a series of bytes at the current position, taken from a byte array.
     * @param buffer The buffer containing a series of bytes.
     * @param position The position in the buffer where the series of bytes are located. 
     * @param length The length of the byte buffer.
     * @throws IOException Not thrown from this implementation 
     */
    public void putBytes(byte[] buffer, long position, long length) throws IOException
    {
        if (buffer == null || length == 0) return;
        _buffer.put(buffer, (int)position, (int)length);
    }

    /**
     * Gets the series of bytes at the current position, this is done by copying them into a {@link Field}
     * object. 
     * @param outField The Field object used to copy the byte sequence.
     * @param length The length of the Field object.
     * @throws IOException Not thrown from this implementation 
     */
    public void getBytes(Field outField, int length) throws IOException
    {
        outField.length = length;
        if (outField.length == 0)
        {
            outField.buffer = null;
            outField.position = 0;
        }
        else if(_buffer.hasArray())
        {
            outField.buffer = _buffer.array();
            outField.position = _buffer.position();
            _buffer.position((int)(outField.position + outField.length));
        }
        else
        {
            outField.buffer = new byte[outField.length];
            outField.position = 0;
            _buffer.get(outField.buffer, 0, (int)outField.length);
        }
    }

    /**
     * Sets the offset and length of the buffer to 0.
     * @param offset The offset to set as 0.
     * @param length The length to set as 0.
     * @throws IOException Not thrown from this implementation 
     */
    public void zero(long offset, int length) throws IOException
    {
       for(long i = 0; i < length; i+=8)
       {
           _buffer.putLong((int)offset + (int)i, 0);
       }
        
    }

    public void close() throws Exception
    {
        _buffer = null;
        _store = null;
    }
}
