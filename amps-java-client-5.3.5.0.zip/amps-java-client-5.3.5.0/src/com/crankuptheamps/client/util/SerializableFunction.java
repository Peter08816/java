////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client.util;

import java.io.Serializable;
import java.util.Properties;

import com.crankuptheamps.client.Client;

/**
 * <p>This generic utility interface has been added to the AMPS client to better
 * support interoperability with other AMPS components and third-party software.
 * Implementations of this interface can represent any function that takes a
 * single argument and returns a result. This function is tagged to be
 * serializable.</p>
 * 
 * <p>Example usages of this interface include the following:</p>
 * 
 * <p>Within the AMPS/Apache Spark integration component, there is a need for a
 * serializable function that returns an AMPS {@link Client}, given a Java
 * {@link Properties} object. Such implementations would have this signature:
 * SerializableFunction&lt;Properties, Client&gt;</p>
 * 
 * <p>Within the 60East Spark utility client, there is an interface called
 * AuthenticatorFactory, whose single method has the following signature:</p>
 * 
 * <code>
 * Authenticator createAuthenticator(String connectionURI)
 * </code>
 * 
 * <p>End-users can instead provide an implementation of this
 * interface using the following signature:
 * SerializableFunction&lt;String, Authenticator&gt;</p>
 * 
 * <p>NOTE: In a future release, once support for Java 7 is dropped, this
 * interface will be modified to also extend java.util.function.Function</p>
 *
 * @param <T> The type of the input to the function.
 * @param <R> The type of the returned result of the function.
 */
public interface SerializableFunction<T,R> extends Serializable {
    /**
     * Invokes the function with the specified argument of type T and returns
     * a result of type R.
     * @param t the argument to provide to the function
     * @return the result of calling the function with the provided argument
     */
    R apply(T t);
}
