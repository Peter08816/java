////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.DisconnectedException;
import java.util.Collection;

/**
 * A simple ServerChooser that keeps a list of AMPS instances and
 * Authenticators, and advances to the next one when failure occurs.
 *
 * <pre>
 * <code>
 * DefaultServerChooser sc = new DefaultServerChooser();
 * sc.add("tcp://127.0.0.1:9017/amps");
 * client.setServerChooser(sc);
 * </code>
 * </pre>
 */
public class DefaultServerChooser implements ServerChooser
{
    String[] _uris;
    private static final int DEFAULT_SIZE = 5;
    int _currentFree, _current;

    /**
     * Constructs a DefaultServerChooser instance with default settings.
     */
    public DefaultServerChooser()
    {
        _uris = new String[DEFAULT_SIZE];
        _currentFree = 0;
        _current = 0;
    }

    /**
     * Adds a URI to self.
     * @param uri The AMPS URI to add to the list.
     * @return Returns this instance so that various operations can be chained together.
     */
    public DefaultServerChooser add(String uri)
    {
        if (_currentFree >= _uris.length)
        {
            String[] newUris = new String[_uris.length * 2];
            System.arraycopy(_uris, 0, newUris, 0, _uris.length);
            _uris = newUris;
        }

        _uris[_currentFree] = uri;
        ++_currentFree;
        return this;
    }

    /**
     * Adds URIs to self.
     * @param <T> A type that extends Collection&lt;String&gt;.
     * @param uris The AMPS URIs to add to the list.
     * @return Returns this instance so that various operations can be chained together.
     */
    public <T extends Collection<String> > DefaultServerChooser addAll(T uris)
    {
        int urisSize = uris.size();
        if (_currentFree >= _uris.length - urisSize)
        {
            int newLength = (_uris.length<urisSize)?_uris.length+urisSize:_uris.length*2;
            String[] newUris = new String[newLength];
            System.arraycopy(_uris, 0, newUris, 0, _uris.length);
            _uris = newUris;
        }

        for (String uri : uris)
        {
            _uris[_currentFree] = uri;
            ++_currentFree;
        }
        return this;
    }

    /**
     * Gets the current URI.
     * @return The current URI.
     */
    public String getCurrentURI()
    {
        if (_currentFree == 0)
        {
            return null;
        }
        if (_current >= _currentFree)
        {
            _current = 0;
        }
        return _uris[_current];
    }

    /**
     * Returns the Authenticator instance associated with the current URI.
     * @return Returns an {@link Authenticator} or null if none is required for logon.
     */
    public Authenticator getCurrentAuthenticator()
    {
        return null;
    }

    /**
     * Called by {@link HAClient} when an error occurs connecting to the current URI,
     * and/or when an error occurs logging on. Implementors will likely advance the current
     * URI to the next one in a list, or choose to stay with the current one, based on the
     * exception type.
     * @param exception The exception associated with this failure.
     * @param info Information about the connection that failed.
     * @throws Exception Allows any exception to be thrown: the exception will be reported to the ExceptionListener registered for the client
     */
    public void reportFailure(Exception exception, ConnectionInfo info) throws Exception
    {
        // In either case we'll just move on to the next
        // server whenever we have a failure connecting.
        // If we just got disconnected, though, we'll retry.
        if (!(exception instanceof DisconnectedException))
        {
            next();
        }
    }

    /**
     * Report success is not used in this implementation.
     */
    public void reportSuccess(ConnectionInfo info)
    {
        // This implementation does not use success.
    }

    /**
     * Advances to the next URI in the list of URIs.
     */
    public void next()
    {
        _current = (_current + 1) % _currentFree;
    }

    /**
     * Provides additional details to be included in an exception thrown when the AMPS instance(s)
     * are not available. Called by {@link HAClient} when creating an exception.
     * @return Returns a {@link String} with information about the connection that failed and the
     * reason for the failure. When no further information is available, returns an empty string.
     */
    public String getError()
    {
        return "";
    }
}
