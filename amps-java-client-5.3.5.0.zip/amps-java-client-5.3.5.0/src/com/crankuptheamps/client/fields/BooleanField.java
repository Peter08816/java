////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client.fields;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Field data for a {@link com.crankuptheamps.client.Message} consisting
 * of a boolean value.
 */
public class BooleanField extends Field
{
    protected static final Charset LATIN1      = StandardCharsets.ISO_8859_1;
    protected static final byte   LATIN1_ZERO  = 48;

    private static byte[] BT_TRUE                     = null;
    private static byte[] BT_FALSE                    = null;

    static
    {
        BT_TRUE                     = "true".getBytes(LATIN1);
        BT_FALSE                    = "false".getBytes(LATIN1);
    }

    /**
     * Gets the value for the boolean field.
     * @return Returns value for the boolean field.
     */
    public boolean getValue()
    {
        if( this.length == 4 && this.buffer[0] == (byte)'t')
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Sets the value of the boolean field.
     * @param v The boolean value to set.
     */
    public void setValue(boolean v)
    {
        if(v)
        {
            set( BT_TRUE, 0, 4 );
        }
        else
        {
            set( BT_FALSE, 0, 5 );
        }
    }
}