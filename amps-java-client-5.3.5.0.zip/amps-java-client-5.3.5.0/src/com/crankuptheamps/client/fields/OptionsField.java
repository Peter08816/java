////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client.fields;

import java.io.UnsupportedEncodingException;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;

/**
* Field data for a {@link com.crankuptheamps.client.Message} which
* consists of options. These options represent the possible values
* for message options in an AMPS command.
*/
public class OptionsField extends StringField
{
    /**
     * Initializes a new instance of the OptionsField class with the
     * specified buffer, position, and length.
     * @param buffer    The byte array buffer containing the options.
     * @param position  The starting position of the options within
     *                  the buffer.
     * @param length    The length of the options.
     */
    protected OptionsField(byte[] buffer, int position, int length)
    {
        super(buffer, position, length);
        if(this.buffer != null)
        {
            int len = this.length;
            if (len > 0 && buffer[this.position+len-1] == ',') --this.length;
        }
    }

    /**
     * Initializes a new instance of the OptionsField class with
     * the specified value.
     * @param value The string value representing the options.
     */
    public OptionsField(String value)
    {
        super(value);
    }

    /**
     * Initializes a new instance of the OptionsField class.
     */
    public OptionsField()
    {
    }

    /**
     * Sets the value of this OptionsField using the specified byte array,
     * offset, and length. Trailing commas are handled appropriately.
     * @param v      The byte array containing the value to set.
     * @param offset The starting offset in the byte array.
     * @param length The length of the value to set.
     */
    @Override
    public void setValue(byte[] v,int offset,int length)
    {
        super.setValue(v, offset, length);
        if(this.buffer != null)
        {
            int len = this.length;
            if (len > 0 && buffer[this.position+len-1] == ',') --this.length;
        }
    }

    /**
     * Sets the value of this OptionsField using the specified string
     * value and charset encoder. Trailing commas are handled appropriately.
     * @param v       The string value to set.
     * @param encoder The charset encoder to use.
     */
    @Override
    public void setValue(String v, CharsetEncoder encoder)
    {
        super.setValue(v, encoder);
        if(this.buffer != null)
        {
            int len = this.length;
            if (len > 0 && buffer[this.position+len-1] == ',') --this.length;
        }
    }

    /**
     * Retrieves the value of this OptionsField as a string using the specified
     * charset decoder. Trailing commas are handled appropriately.
     * @param decoder The charset decoder to use.
     * @return The string value of this OptionsField.
     */
    @Override
    public String getValue(CharsetDecoder decoder)
    {
        if(this.buffer != null)
        {
            int len = this.length;
            if (len > 0 && buffer[this.position+len-1] == ',') --this.length;
            return new String(this.buffer,this.position,this.length,decoder.charset());
        }
        return null;
    }

    /**
     * Retrieves the value of this OptionsField as a byte buffer.
     * Trailing commas are handled appropriately.
     * @param v The byte buffer to store the value.
     * @return True if the value was successfully retrieved, false
     *         otherwise.
     */
    @Override
    public boolean getValue(ByteBuffer v)
    {
        if(this.buffer != null)
        {
            int len = this.length;
            if (len > 0 && buffer[this.position+len-1] == ',') --this.length;
            v.put(this.buffer,this.position,this.length);
            return true;
        }
        return false;
    }

    /**
     * Implementation for {@link Object#equals} for an OptionsField. For two
     * OptionsFields to be considered equal, their values must have the same
     * length and all bytes in the value must be equal, other than a possible
     * trailing comma.
     * @param obj The object to compare this with.
     */
    public boolean equals(Object obj)
    {
        if(obj == null || !(obj instanceof OptionsField))
        {
            if (obj instanceof Field) return super.equals(obj);
            return false;
        }
        int len = this.length;
        if (len > 0 && buffer[this.position+len-1] == ',') --len;
        OptionsField o = (OptionsField)obj;
        int oLen = o.length;
        if (oLen > 0 && o.buffer[o.position+oLen-1] == ',') --oLen;
        if(oLen != len) return false;
        for(int i=0; i< len; i++)
        {
            if(o.buffer[o.position+i] != buffer[position+i]) return false;
        }
        return true;
    }

    /**
     * Implementation of {@link Object#hashCode} for an OptionsField.
     */
    public int hashCode()
    {
        // for large sets of short, similar byte sequences this can produce
        // lots of collision
        int result = 0;
        int len = this.length;
        if (len > 0 && buffer[this.position+len-1] == ',') --len;
        for(int i = 0; i < len; i++)
        {
            result += buffer[position+i];
        }
        return result;
    }

}