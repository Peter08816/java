////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.StoreException;

/**
 * An in-memory publish store, used to provide republish capability when
 * a server fails over.
 * <p>
 * Publish stores hold messages until the AMPS server has
 * acknowledged that they are persisted. When the client detects disconnection
 * and reconnects, the client can republish any messages which have not
 * been acknowledged by AMPS.
 * </p>
 * <p>
 * Use this PublishStore when you are only concerned about server failover:
 * MemoryPublishStore does not protect you in case of subscriber failure,
 * because it has no persisted backing store.
 * </p>
 */
public class MemoryPublishStore extends BlockPublishStore {

  /**
   * The size of each block the store allocates.
   */
  public static final int BLOCK_SIZE = BlockPublishStore.Block.SIZE; // 2048

  /**
   * Construct an in-memory public store with the specified number of
   * blocks as the initial capacity. The initial memory footprint will be
   * initialCapacity * BLOCK_SIZE bytes.
   *
   * @param initialCapacity The number of blocks to allocate on construction
   * @throws StoreException Thrown when an operation fails with details of the
   *                        failure.
   */
  public MemoryPublishStore(int initialCapacity) throws StoreException {
    // passes an ArrayStoreBuffer as the storage mechanism, the initialCapacity, and
    // false to indicate that no CRC (Cyclic Redundancy Check) operations are
    // performed.
    super(new ArrayStoreBuffer(), initialCapacity, false);
    if (_usedList == null) {
      growFreeListIfEmpty();
    }
    recover();
    getLastPersisted();
    firstGapCheckDone = false;
  }

  @Override
  public void discardUpTo(long index) throws StoreException
  {
    super.discardUpTo(index);
    if (!firstGapCheckDone) { firstGapCheckDone = true; }
  }

  @Override
  public boolean getErrorOnPublishGap()
  {
    return firstGapCheckDone ? super.getErrorOnPublishGap() : false;
  }

  private boolean firstGapCheckDone;
}
