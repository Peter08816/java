////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.*;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Used to give a unique identifier to a {@link Command}. This Id can be used to reference 
 * the command later, such as when unsubscribing a subscription command. 
 */

public class CommandId
{
    public  byte[] id   = null;
    private int    hash = 0;
    static java.util.concurrent.atomic.AtomicLong _currentCommandId = new AtomicLong();
    
    /**
     * Returns the next Id for the current command.
     * @return Next command identifier.
     */

    public static CommandId nextIdentifier()
    {
        return new CommandId(String.format("auto%d", _currentCommandId.incrementAndGet()).getBytes(StandardCharsets.ISO_8859_1));
    }

    CommandId()
    {
    }

    /**
     * Constructs a CommandId for an AMPS command, using a string as its identifier.
     * @param string A string used to set the new identifier for this AMPS command.
     */

    public CommandId(String string)
    {
        if(string != null)
        {
            this.id = string.getBytes(StandardCharsets.ISO_8859_1);
            hash = Arrays.hashCode(id);
        }

    }

    /**
     * Constructs a Command Id for an AMPS command, using an array of bytes as its identifier.
     * @param buffer An array of bytes used to set the new identifier for this AMPS command.
     */

    public CommandId(byte[] buffer)
    {
        this.id = buffer;
        hash = Arrays.hashCode(id);
    }

    /**
     * Constructs a Command Id for an AMPS command, using an array of bytes, a position number, and a length
     * as its identifier.
     * @param buffer An array of bytes used to set the new identifier for this AMPS command.
     * @param position An integer used to represent the position that the buffer should start.
     * @param length An integer used to determine the length of the new identifier.
     */

    public CommandId(byte[] buffer, int position, int length)
    {
        this.id = new byte[length];
        System.arraycopy(buffer,position,id,0,length);
        hash = Arrays.hashCode(id);
    }

    /**
     * Sets the CommandId for the AMPS command.
     * @param buffer An array of bytes used to set the CommandId.
     * @param length Length of the new id.
     * @param position Position where the new CommandId should start.
     */
    
    public void set(byte[] buffer, int position, int length)
    {
        if(this.id == null || this.id.length != length) this.id = new byte[length];
        System.arraycopy(buffer,position,id,0,length);
        hash = Arrays.hashCode(this.id);
    }

    /**
     * Overridden to test equality based upon object class and the CommandId value. For this to return 
     * true, the passed in instance must be an instance of CommandId and its value must be binary equal 
     * to this instance's value. 
     */
    public boolean equals(Object obj)
    {
        return (obj instanceof CommandId
                && Arrays.equals(id,((CommandId)obj).id));
    }

    /**
     * Overridden to return a hash code that is based upon CommandId value.
     */
    public int hashCode()
    {
        return hash;
    }

    /**
     * Overridden to return the CommandId value as a string where each byte is interpreted as an ISO-8859-1
     * character.
     */
    public String toString()
    {
        return new String(id, StandardCharsets.ISO_8859_1);
    }

}

