////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2017-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

/**
 * Provides an easy way to extract the date/time parts from an AMPS timestamp.
 *
 */
public class AMPSTimestamp
{
    /**
     * The length of a valid AMPS timestamp in bytes.
     */
    public static final int AMPS_TIMESTAMP_LENGTH = 23;

    /**
     * Year part of this timestamp.
     */
    public int year;
    /**
     * Month part of this timestamp.
     */
    public int month;
    /**
     * Day part of this timestamp.
     */
    public int day;
    /**
     * Hour part of this timestamp.
     */
    public int hour;
    /**
     * Minute part of this timestamp.
     */
    public int minute;
    /**
     * Seconds part of this timestamp.
     */
    public int second;
    /**
     * Nanos part of this timestamp.
     */
    public int nano;
    
    /**
     * Parse an AMPS timestamp from a string.
     * @param data The input AMPS timestamp to parse.
     * @param out The timestamp object to parse into.
     */
    public static void parse(String data, AMPSTimestamp out)
    {
        if(data.length() != AMPS_TIMESTAMP_LENGTH)
            throw new RuntimeException("Timestamp length incorrect -- this is not an AMPS timestamp.");
       
        out.year =  ((data.charAt(0) - '0') * 1000)+
                    ((data.charAt(1) - '0') * 100)+
                    ((data.charAt(2) - '0') * 10)+
                     (data.charAt(3) - '0');
        out.month = ((data.charAt(4) - '0') * 10) +
                     (data.charAt(5) - '0');
        out.day   = ((data.charAt(6) - '0') * 10) +
                     (data.charAt(7) - '0');
        out.hour  = ((data.charAt(9) - '0') * 10) +
                     (data.charAt(10)- '0');
        out.minute= ((data.charAt(11)- '0') * 10) +
                     (data.charAt(12)- '0');
        out.second= ((data.charAt(13)- '0') * 10) +
                     (data.charAt(14)- '0');
        out.nano = ((data.charAt(16)- '0') * 100000000)+
                   ((data.charAt(17)- '0') * 10000000)+
                   ((data.charAt(18)- '0') * 1000000)+
                   ((data.charAt(19)- '0') * 100000)+
                   ((data.charAt(20)- '0') * 10000)+
                   ((data.charAt(21)- '0') * 1000);
    }
    
    /**
     * Parse an AMPS timestamp from a byte array.
     * @param data The byte array containing the AMPS timestamp.
     * @param offset The offset in data where the timestamp begins.
     * @param length The length of the timestamp.
     * @param out The timestamp object to parse into.
     */
    public static void parse(byte[] data, int offset, int length, AMPSTimestamp out)
    {
        if(length != AMPS_TIMESTAMP_LENGTH)
            throw new RuntimeException("Timestamp length incorrect -- this is not an AMPS timestamp.");

        out.year =  ((data[offset] - '0') * 1000)+
                    ((data[offset+1] - '0') * 100)+
                    ((data[offset+2] - '0') * 10)+
                     (data[offset+3] - '0');
        out.month = ((data[offset+4] - '0') * 10) +
                     (data[offset+5] - '0');
        out.day   = ((data[offset+6] - '0') * 10) +
                     (data[offset+7] - '0');
        out.hour  = ((data[offset+9] - '0') * 10) +
                     (data[offset+10]- '0');
        out.minute= ((data[offset+11]- '0') * 10) +
                     (data[offset+12]- '0');
        out.second= ((data[offset+13]- '0') * 10) +
                     (data[offset+14]- '0');
        out.nano = ((data[offset+16]- '0') * 100000000)+
                   ((data[offset+17]- '0') * 10000000)+
                   ((data[offset+18]- '0') * 1000000)+
                   ((data[offset+19]- '0') * 100000)+
                   ((data[offset+20]- '0') * 10000)+
                   ((data[offset+21]- '0') * 1000);
    }
    
    /**
     * Parses an AMPS timestamp into a new object.
     * 
     * @param data The AMPS timestamp to parse.
     */
    public AMPSTimestamp(String data)
    {
        parse(data,this);
    }
    
    /**
     * Parses an AMPS timestamp into a new object.
     * @param data The byte array containing the AMPS timestamp.
     * @param offset The offset in data where the timestamp begins.
     * @param length The length of the timestamp.
     */
    public AMPSTimestamp(byte[] data, int offset, int length)
    {
        parse(data,offset,length,this);
    }
}
