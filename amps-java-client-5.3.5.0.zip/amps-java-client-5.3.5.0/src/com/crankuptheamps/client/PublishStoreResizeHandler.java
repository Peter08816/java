////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

/**
 * Interface used to indicate whether a Store implementation is allowed to
 * grow (or shrink) to the requested size. If the request to resize is
 * denied, a Store implementation may fail the operation that resulted in
 * the request to grow by throwing an exception.
 * 
 * <p>
 * <strong>Implementation Example:</strong>
 * </p>
 * 
 * <pre>
 * public class MaxSizeResizeHandler implements PublishStoreResizeHandler, ConnectionStateListener {
 *     protected long maxSize; // Maximum allowed size for the publish store 
 *     protected long timeout; // Timeout for store flushing
 *     protected int maxFlushAttempts; // Maximum number of attempts to flush the store
 *     protected volatile boolean connected = false; // Keeps track of the connection state
 * 
 *     public MaxSizeResizeHandler (long maxSize, long timeout, int maxFlushAttempts) {
 *         this.maxSize = maxSize;
 *         this.timeout = timeout;
 *         this.maxFlushAttempts = maxFlushAttempts;
 *     }
 * 
 *     &#64;Overide
 *     public boolean invoke(Store store, long newSize) {
 *         try {
 *             if(newSize &lt;= maxSize)
 *                 return true;
 * 
 *             // Use your preferred logging API instead of println() calls.
 *             System.out.println("\n------- Resize Handler Called And Over Max Size --------");
 * 
 *             long startCount=store.unpersistedCount();
 *             System.out.println("Unpersisted count before flush: " + startCount);
 * 
 *             // We've reached max size. Try to flush store instead of growing it.
 *             long count=startCount;
 *             int tries=0;
 *             while(count &gt; 0 &amp;&amp; tries++ &lt; maxFlushAttempts) {
 *                 System.out.println("Store not empty. Unpersisted msg count = " + count);
 *                 System.out.println("Flush attempt = " + tries + ", connected status = " + connected);
 *                 try {
 *                     store.flush(timeout);
 *                 }
 *                 catch(TimedOutException e) { &#47;* ignore *&#47; }
 *                 count=store.unpersistedCount();
 *             }
 *             long endCount=store.unpersistedCount();
 *             System.out.println("Unpersisted count after flush attempt(s): " + endCount
 *                 + ", connected = " + connected);
 *         } catch(Exception e) {
 *              e.printStackTrace();
 *         }
 * 
 *         // Let the store know it can't grow. Hopefully space was freed up.
 *         return false;
 *     }
 * 
 *     &#64;Overide 
 *     public void connectionStateChanged(int state) {
 *         switch(state) {
 *         case ConnectionStateListener.Connected:
 *         case ConnectionStateListener.LoggedOn:
 *         case ConnectionStateListener.HeartbeatInitiated:
 *         case ConnectionStateListener.PublishReplayed:
 *         case ConnectionStateListener.Resubscribed:
 *             connected = true;
 *             break;
 *         case ConnectionStateListener.Disconnected:
 *         case ConnectionStateListener.Shutdown:
 *             connected = false;
 *             break;
 *         }
 *     }
 * }
 * </pre>
 * 
 * <p>
 * <strong>How to use your resize handler:</strong>
 * </p>
 * 
 * <pre> 
 *     client = new HAClient("PubClient");
 *     Store pubStore = new MemoryPublishStore(100);
 *     MaxSizeResizeHandler handler = new MaxSizeResizeHandler(maxSize, timeout, maxFlushAttempts);
 *     pubStore.setResizeHandler(handler);
 *     client.setPublishStore(pubStore);
 *     client.addConnectionStateListener(handler);
 * </pre>
 * 
 * <p>
 * You can implement your custom resize handler by implementing the
 * {@link PublishStoreResizeHandler} interface and then setting it using the
 * {@link PublishStore#setResizeHandler(PublishStoreResizeHandler)} method.
 * </p>
 */
public interface PublishStoreResizeHandler
{
    /**
     * Called by the {@link Store} when it wants to attempt a resize. Rather
     * than allow a resize request to grow the store, and implementation
     * could choose to flush the store (to allow space to be freed up)
     * at the expense of publishing performance. If the store's unpersisted
     * count doesn't decrease after a flush times out, it could indicate
     * the client is disconnected or a server-side issue such as a
     * synchronous replication destination is down.
     *
     * @param store The store sending the resize request.
     * @param size The new size the store would like to resize to.
     * @return A boolean indicating whether the Store is allowed to resize or not.
     */
    public boolean invoke(Store store, long size);
}
