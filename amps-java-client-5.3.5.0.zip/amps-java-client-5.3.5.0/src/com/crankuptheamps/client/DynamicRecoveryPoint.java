///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.AMPSException;
import com.crankuptheamps.client.fields.BookmarkField;
import com.crankuptheamps.client.fields.Field;

/**
 * Interface to provide a recovery point for a bookmark subscription.
 * Used in the RecoveryPointAdapter interface for updates and recovery.
 */
class DynamicRecoveryPoint implements RecoveryPoint {
    private Field _subId = null;
    private BookmarkStore _store = null;

    /**
     * Initializes a new instance of the DynamicRecoveryPoint class with the specified parameters.
     * @param store_ The bookmark store.
     * @param subId_ The subscription id.
     */
    public DynamicRecoveryPoint(BookmarkStore store_, Field subId_) {
        _subId = subId_;
        _store = store_;
    }

    /**
     * Return the subscription id for this recovery point
     */
    public Field getSubId() {
        return _subId;
    }

    /**
     * Return the bookmark for this recovery point
     * @return The bookmark for this recovery point.
     */
    public BookmarkField getBookmark() {
        try {
            return (BookmarkField)_store.getMostRecent(_subId, false);
        }
        catch (AMPSException ignore) {
        }
        return null;
    }

    /**
     * Return a deep copy of self.
     * @return A deep copy of self.
     */
    public RecoveryPoint copy() {
        return new DynamicRecoveryPoint(_store, _subId.copy());
    }
}

