////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.Field;
import java.io.IOException;
import java.util.Arrays;

import com.crankuptheamps.client.BlockPublishStore.ByteSequence;

/**
 * ArrayStoreBuffer is a simple wrapper for a java array that maintains position.
 * Very similar to the {@link MemoryStoreBuffer}, but instead of using a ByteBuffer, 
 * it just uses an array directly.  Resize may be a tad more expensive, but
 * steady-state latencies are significantly lower.
 */
public class ArrayStoreBuffer implements BlockPublishStore.Buffer
{
    byte[] _buf = null;
    volatile int _pos = 0;
    Store _store = null;

    /**
     * Gets the back buffer. 
     * @return The end buffer.
     */
    public byte[] getBuffer() { return _buf; }
   
    /**
     * Gets the size of the back buffer. 
     * @return Length of the buffer.
     * @throws IOException Not thrown from this implementation.
     */
    public long getSize() throws IOException
    {
        return _buf==null?0:_buf.length;
    }
   
    /**
     * Sets the size of the back buffer. 
     * @param newSize The number to be set as the new buffer size.
     * @throws IOException  Not thrown from this implementation.
     */
    public void setSize(long newSize) throws IOException
    {
        byte[] oldBuf = _buf;
        if(oldBuf == null || newSize > oldBuf.length)
        {
            byte[] newBuf = new byte[(int)newSize];

            if(oldBuf != null && oldBuf.length > 0)
            {
                System.arraycopy(oldBuf, 0, newBuf, 0, oldBuf.length);
            }
            _buf = newBuf;
        }
    }

    /**
     * Gets the current position in the buffer.
     * @return The current position. 
     * @throws IOException Not thrown from this implementation.
     */
    public long getPosition() throws IOException
    {
        return _pos;
    }

    /**
     * Sets the current position in the buffer. 
     * @param position The current position to set. 
     * @throws IOException Not thrown from this implementation.
     */
    public void setPosition(long position) throws IOException
    {
        _pos = (int)position;
        
    }

    /**
     * Writes the byte into the buffer. 
     * @param b The byte to place in the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putByte(byte b) throws IOException
    {
        _buf[_pos++] = b;
        
    }

    /**
     * Gets the byte from the buffer. 
     * @return The byte from the buffer.
     * @throws IOException  Not thrown from this implementation.
     */
    public byte getByte() throws IOException
    {
        return _buf[_pos++];
    }

    /**
     * Writes the integer into the buffer.
     * @param i The integer to place in the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putInt(int i) throws IOException
    {
        _buf[_pos++] = (byte)((i & 0xFF000000) >> 24);
        _buf[_pos++] = (byte)((i & 0xFF0000) >> 16);
        _buf[_pos++] = (byte)((i & 0xFF00) >> 8);
        _buf[_pos++] = (byte)(i & 0xFF);
    }

    /**
     * Puts the integer into the buffer. 
     * @param position The position in the buffer to place the integer. 
     * @param i The integer to place in the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */ 
    public void putInt(long position, int i) throws IOException
    {
        int pos = (int) position;
        _buf[pos++] = (byte)((i & 0xFF000000) >> 24);
        _buf[pos++] = (byte)((i & 0xFF0000) >> 16);
        _buf[pos++] = (byte)((i & 0xFF00) >> 8);
        _buf[pos] = (byte)(i & 0xFF);
    }

    /**
     * Gets the integer from the buffer. 
     * @return The integer from the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public int getInt() throws IOException
    {
        int result = _buf[_pos+3] & 0xff |
                ((_buf[_pos+2]&0xff) << 8) |
                ((_buf[_pos+1]&0xff) << 16) |
                ((_buf[_pos+0]&0xff) << 24);
        _pos += 4;
        return result;
    }

    /** 
     * Gets the integer from the buffer. 
     * @param position The position in the buffer where the integer should begin.
     * @return The integer from the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public int getInt(long position) throws IOException
    {
        int pos = (int)position;
        return  (  _buf[pos+3] & 0xff |
                 ((_buf[pos+2]&0xff) << 8) |
                 ((_buf[pos+1]&0xff) << 16) |
                 ((_buf[pos+0]&0xff) << 24));
    }

    /**
     * Writes the long into the buffer. 
     * @param l The long to be placed in the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putLong(long l) throws IOException
    {
        _buf[_pos++] = (byte)((l & 0xFF00000000000000L) >> 56);
        _buf[_pos++] = (byte)((l & 0xFF000000000000L) >> 48);
        _buf[_pos++] = (byte)((l & 0xFF0000000000L) >> 40);
        _buf[_pos++] = (byte)((l & 0xFF00000000L) >> 32);
        _buf[_pos++] = (byte)((l & 0xFF000000L) >> 24);
        _buf[_pos++] = (byte)((l & 0xFF0000L) >> 16);
        _buf[_pos++] = (byte)((l & 0xFF00L) >> 8);
        _buf[_pos++] = (byte)(l & 0xFFL);
    }

    /**
     * Writes the long into the buffer. 
     * @param position The position where the long should be placed in the buffer.  
     * @param l The long to be placed in the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putLong(long position, long l) throws IOException
    {
        int pos = (int) position;
        _buf[pos++] = (byte)((l & 0xFF00000000000000L) >> 56);
        _buf[pos++] = (byte)((l & 0xFF000000000000L) >> 48);
        _buf[pos++] = (byte)((l & 0xFF0000000000L) >> 40);
        _buf[pos++] = (byte)((l & 0xFF00000000L) >> 32);
        _buf[pos++] = (byte)((l & 0xFF000000L) >> 24);
        _buf[pos++] = (byte)((l & 0xFF0000L) >> 16);
        _buf[pos++] = (byte)((l & 0xFF00L) >> 8);
        _buf[pos] = (byte)(l & 0xFFL);
    }

    /**
     * Gets the long from the buffer.  
     * @return The long from the buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public long getLong() throws IOException
    {
        long result = _buf[_pos+7] & 0xff |
                ((long)(_buf[_pos+6]&0xff) << 8) |
                ((long)(_buf[_pos+5]&0xff) << 16) |
                ((long)(_buf[_pos+4]&0xff) << 24) |
                ((long)(_buf[_pos+3]&0xff) << 32) |
                ((long)(_buf[_pos+2]&0xff) << 40) |
                ((long)(_buf[_pos+1]&0xff) << 48) |
                ((long)(_buf[_pos+0]&0xff) << 56);
        _pos += 8;
        return result; 
    }

    /**
     * Writes a series of bytes at the current position, taken from the specified {@link BlockPublishStore.ByteSequence}.
     * @param bytes The series of bytes to write at the current position. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putBytes(ByteSequence bytes) throws IOException
    {
        if (bytes.array == null || bytes.len == 0) return;
        System.arraycopy(bytes.array, (int)bytes.offset, _buf, _pos, (int)bytes.len);
        _pos += bytes.len;
    }

    /**
     * Gets the series of bytes at the current position by placing them into the provided
     * {@link BlockPublishStore.ByteSequence} object. 
     * @param outBytes The provided ByteSequence object. 
     * @throws IOException  Not thrown from this implementation.
     */ 
    public void getBytes(ByteSequence outBytes) throws IOException
    {
        if (outBytes.len == 0) return;
        outBytes.array = _buf;
        outBytes.offset = _pos;
        _pos += outBytes.len;
    }

    /**
     * Writes a series of bytes at the current position, taken from a byte array. 
     * @param buffer The buffer containing a series of bytes. 
     * @param position The position in the buffer where the series of bytes are located. 
     * @param length The length of the byte buffer. 
     * @throws IOException  Not thrown from this implementation.
     */
    public void putBytes(byte[] buffer, long position, long length) throws IOException
    {
        if (buffer == null || length == 0) return;
        System.arraycopy(buffer, (int)position, _buf, _pos, (int)length);
        _pos += length;
    }

    /** 
     * Gets the series of bytes at the current position, this is done by copying them into a {@link Field} object. 
     * @param outField The Field object used to copy the byte sequence.
     * @param length The length of the Field object.
     * @throws IOException  Not thrown from this implementation.
     */
    public void getBytes(Field outField, int length) throws IOException
    {
        outField.length = length;
        if (outField.length == 0)
        {
            outField.buffer = null;
            outField.position = 0;
        }
        else
        {
            outField.buffer = _buf;
            outField.position = _pos;
            _pos += outField.length;
        }
    }

    /**
     * Sets the buffer, offset, and length to 0.
     * @param offset The offset to set as 0.
     * @param length The length to set as 0.
     * @throws IOException  Not thrown from this implementation.
     */
    public void zero(long offset, int length) throws IOException
    {
        Arrays.fill(_buf, (int)offset, (int)offset+length, (byte)0);
    }

    public void close()
    {
        _buf = null;
        _store = null;
        _pos = -1;
    }
}
