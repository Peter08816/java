////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;
import com.crankuptheamps.client.exception.AMPSException;

/**
 * A no-op implementation of the {@link SubscriptionManager} interface that does
 * nothing. 
 */
public class DefaultSubscriptionManager implements SubscriptionManager
{
    /**
     * Subscribes to a message handler with a message.
     * @param messageHandler The message handler to subscribe.
     * @param message The message to subscribe to.
     */
    public void subscribe(MessageHandler messageHandler, Message message)
    {
    }

    /**
     * Unsubscribes a subscription by subId.
     * @param subId The subscription ID to unsubscribe.
     */
    public void unsubscribe(CommandId subId)
    {
    }

    /**
     * Clears all subscriptions.
     */
    public void clear()
    {
    }

    /**
     * Resubscribes using the provided client.
     * @param client The client to resubscribe.
     * @throws AMPSException If an error occurs during resubscription.
     */
    public void resubscribe(Client client) throws AMPSException
    {
    }

    /**
     * Gets the failed resubscribe handler.
     * @return The failed resubscribe handler.
     */
    public FailedResubscribeHandler getFailedResubscribeHandler()
    {
        return null;
    }

    /**
     * Sets the failed resubscribe handler.
     * @param failureHandler The failed resubscribe handler to set.
     */
    public void setFailedResubscribeHandler(FailedResubscribeHandler failureHandler)
    {
    }

}
