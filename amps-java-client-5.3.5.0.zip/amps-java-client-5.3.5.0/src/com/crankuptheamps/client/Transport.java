////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.beans.ExceptionListener;
import java.net.URI;
import java.lang.AutoCloseable;

import com.crankuptheamps.client.exception.AlreadyConnectedException;
import com.crankuptheamps.client.exception.ConnectionRefusedException;
import com.crankuptheamps.client.exception.DisconnectedException;
import com.crankuptheamps.client.exception.InvalidURIException;
import com.crankuptheamps.client.exception.RetryOperationException;

/**
* Interface that is used to manage and configure connections to AMPS. Typically a transport is created and used 
* internally by a {@link Client} instance. There is usually no reason to make direct use of it. 
* Its functionality is best accessed via the client instance.
*/

public interface Transport extends AutoCloseable
{
    /**
     * Connect to an AMPS server.
     * @param uri Specifies the protocol and address of the server.
     * @throws ConnectionRefusedException The connection was refused by the server.
     * @throws AlreadyConnectedException The transport is already connected to a server.
     * @throws InvalidURIException The URI is invalid.
     */
    public void connect(URI uri)throws ConnectionRefusedException, AlreadyConnectedException, InvalidURIException;

    public void disconnect() ;

    public void setMessageHandler(MessageHandler ml);

    public void setDisconnectHandler(TransportDisconnectHandler dh);

    public void setExceptionListener(ExceptionListener exceptionListener);

    public void setThreadCreatedHandler(ThreadCreatedHandler ml);

    public void send(Message message) throws DisconnectedException;

    public void sendWithoutRetry(Message message) throws DisconnectedException;

    public Message allocateMessage();

    public long writeQueueSize() throws DisconnectedException;

    public long readQueueSize() throws DisconnectedException;

    public long flush() throws DisconnectedException;

    public long flush(long timeout) throws DisconnectedException;

    public void handleCloseEvent(int failedVersion_, String message, Exception e) throws DisconnectedException, RetryOperationException;
    
    public int getVersion();
    
    public void setReadTimeout(int readTimeoutMillis_);

    /**
     * Sets a TransportFilter that filters raw bytes before send and after receive.
     * @param filter_ A TransportFilter instance such as com.crankuptheamps.client.TransportTraceFilter.
     */
    public void setTransportFilter(TransportFilter filter_);

    /**
     * Gets the {@link AMPSRunnable} that is invoked during idle-time
     * processing for this connection.
     *
     * @return The currently registered idle runnable or null.
     */
    public AMPSRunnable getIdleRunnable();

    /**
     * Sets a {@link AMPSRunnable} that is invoked during idle-time processing for this connection.
     * @param runnable A {@link AMPSRunnable} instance whose run() method is invoked.
     */
    public void setIdleRunnable(AMPSRunnable runnable);

    /**
     * Called by Client before calling connect to give Transport access to any
     * information in the Client needed by the Transport such as message handler,
     * exceptionListener, etc.
     * @param client The Client that will be using the Transport.
     */
    public void initFromClient(Client client);
}

