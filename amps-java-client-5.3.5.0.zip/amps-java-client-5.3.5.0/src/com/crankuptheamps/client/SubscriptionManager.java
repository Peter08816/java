////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;
import com.crankuptheamps.client.exception.AMPSException;

/**
* Interface used to manage all subscriptions in AMPS. This includes:
* subscribing, unsubscribing and resubscribing. 
*/

public interface SubscriptionManager
{
    /**
     * Creates a subscription. This method is called internally by the client.
     * @param messageHandler The message handler for the subscription.
     * @param message The message for the subscription.
     */
    public void subscribe(MessageHandler messageHandler, Message message);

    /**
     * Unsubscribes from a subscription. 
     * @param subId The subscription ID to identify the subscription.
     */
    public void unsubscribe(CommandId subId);

    /**
     * Clears the subscriptions so they cannot be re-subscribed upon reconnect. 
     */
    public void clear();

    /**
     * Resubscribes to a subscription. 
     * @param client The client object for re-subscription. 
     * @throws AMPSException resubscription failed
     */ 
    public void resubscribe(Client client) throws AMPSException;

    /**
     * Gets the FailedResubscribeHandler.
     * @return The FailedResubscribeHandler or null if not set.
     */
    public FailedResubscribeHandler getFailedResubscribeHandler();

    /**
     * Sets the FailedResubscribeHandler.
     * @param failureHandler A FailedResubscribeHandler to call if a resubscribe fails.
     */
    public void setFailedResubscribeHandler(FailedResubscribeHandler failureHandler);

}
