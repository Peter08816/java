////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;

/**
 * An interface that allows an application to be notified when the
 * client state changes.
 *
 * To use a ConnectionStateListener, you implement this interface,
 * construct an instance of your new class, and then use the
 * {@link Client#addConnectionStateListener addConnectionStateListener}
 * method on the {@link Client} to register for notifications.
 * 
 * See the 'Java Developer Guide' for more details on monitoring
 * connection state.
 * 
 * @since 4.0.0.0
 */
public interface ConnectionStateListener {
    /**
     * Constant passed when the client disconnects.
     * 
     * @since 4.0.0.0
     */
    public final int Disconnected = 0;

    /**
     * Constant passed when the client disconnects and won't reconnect.
     * 
     * @since 5.2.2.0
     */
    public final int Shutdown = 1;

    /**
     * Constant passed when the client connects.
     * 
     * @since 4.0.0.0
     */
    public final int Connected = 2;

    /**
     * Constant passed when the client completes logon.
     * 
     * @since 5.2.2.0
     */
    public final int LoggedOn = 4;

    /**
     * Constant passed when the client completes replay of messages saved in
     * its publish store after logon.
     * 
     * @since 5.2.2.0
     */
    public final int PublishReplayed = 8;

    /**
     * Constant passed when the client has begun heartbeat processing with the
     * server.
     * 
     * @since 5.2.2.0a
     */
    public final int HeartbeatInitiated = 16;

    /**
     * Constant passed when the client has completed resubscribe from
     * the subscription manager.
     * 
     * @since 5.2.2.0
     */
    public final int Resubscribed = 32;

    /**
     * Constant representing an unknown state.
     * 
     * @since 5.2.2.0
     */
    public final int UNKNOWN = 16384;

    /**
     * Called on an implementation of this interface when the connection state
     * changes. This method will be called immediately after the client detects
     * the new state: in particular, this means that when the method is called
     * with a state of {@value Connected}, the client is connected, but has not
     * yet logged on or completed any recovery (such as replaying the publish
     * store, re-entered subscriptions, and so on). The listener should not
     * issue commands on the client while recovery is in progress. Once recovery
     * is complete, if you need to issue a command on this client, it must be
     * executed on another thread. Executing a command within this method will
     * deadlock the client.
     * 
     * @param newState_ The connection state change.
     * @since 4.0.0.0
     */
    void connectionStateChanged(int newState_);
}
