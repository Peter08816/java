////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;
import java.util.HashMap;
import com.crankuptheamps.client.exception.AMPSException;
import com.crankuptheamps.client.fields.Field;
import com.crankuptheamps.client.fields.BookmarkField;

/**
 * A no-op default implementation of the {@link BookmarkStore} interface that 
 * does nothing. 
 */
public class DefaultBookmarkStore implements BookmarkStore
{
    private HashMap<Field, Field> _inMemStore;

    public DefaultBookmarkStore()
    {
        _inMemStore = new HashMap<Field, Field>();
    }

    public synchronized long log(Message message)
    {
        _inMemStore.put(message.getSubIdRaw(), message.getBookmarkRaw());
        return 0;
    }

    public void discard(Field subId, long bookmarkSequenceNumber)
    {
        // No-op
    }
    
    public void discard(Message message) throws AMPSException
    {
    	discard(message.getSubIdRaw(), message.getBookmarkSeqNo());
    }
    
    public synchronized Field getMostRecent(Field subId)
    {
        // return the epoch if we haven't seen anything yet.
        return _inMemStore.containsKey(subId)?_inMemStore.get(subId).copy():new Field("0");

    }

    public synchronized Field getMostRecent(Field subId, boolean useList)
    {
        // return the epoch if we haven't seen anything yet.
        return _inMemStore.containsKey(subId)?_inMemStore.get(subId).copy():new Field("0");

    }

    // all messages should be delivered.
    public boolean isDiscarded(Message message)
    {
        return false;
    }
    
    public synchronized void purge() throws AMPSException
    {
        _inMemStore = new HashMap<Field, Field>();        
    }
    
    public synchronized void purge(Field subId_) throws AMPSException
    {
        _inMemStore.remove(subId_);        
    }

    public void persisted(Field subId, BookmarkField bookmark) throws AMPSException
    {
        // no-op
    }

    public void persisted(Field subId, long bookmark) throws AMPSException
    {
        // no-op
    }

    public synchronized long getOldestBookmarkSeq(Field subId) throws AMPSException
    {
        return 0;
    }

    public void setResizeHandler(BookmarkStoreResizeHandler handler)
    {
        // no-op
    }

    public void setServerVersion(int version_)
    {
        // no-op
    }

    public void close()
    {
        // no-op
    }

}

