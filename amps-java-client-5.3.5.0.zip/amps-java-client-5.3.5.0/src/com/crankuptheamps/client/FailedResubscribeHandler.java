///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;
import com.crankuptheamps.client.exception.AMPSException;

/**
 * Interface for handling failed resubscription events in the AMPS client. The
 * interface provides information about all subscription failures that occur
 * after a fail over event, and allows the implementation to determine if the
 * failures should cause another fail over or if the failing subscription(s)
 * should be ignored and not restarted
 */
public interface FailedResubscribeHandler {

    /**
     * Handles the failure of a resubscription attempt.
     *
     * @param message_        The message that failed to be resubscribed.
     * @param messageHandler_ The message handler associated with the failed
     *                        resubscription attempt.
     * @param requestedAcks_  The OR of all requested ack types using
     *                        Message.AckType to get the int equivalent.
     * @param ex_             The exception (AMPSException) that occurred during the
     *                        resubscription attempt.
     * @return Implementations should return true if they want the client to remain
     *         connected and remove this subscription from tracked subscriptions, or
     *         false if this failure means the client should keep the subscription
     *         and try to fail over again, dropping the current connection.
     * 
     */
    public boolean failure(Message message_,
                           MessageHandler messageHandler_,
                           int requestedAcks_,
                           AMPSException ex_);
}

