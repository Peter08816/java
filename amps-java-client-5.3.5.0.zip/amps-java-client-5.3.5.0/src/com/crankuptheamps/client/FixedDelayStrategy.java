////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;
import com.crankuptheamps.client.exception.*;

/**
 * FixedDelayStrategy is an implementation that delays for a fixed time
 * period, as specified in the constructor, when reconnecting to the same
 * server as we were previously connected to, or if we are invoked again
 * for the first server we ever tried.
 */
public class FixedDelayStrategy implements ReconnectDelayStrategy
{
    /**
     * A specialized exception type thrown by ExponentialDelayStrategy
     * to indicate that the client should "give up" on attempting to
     * reconnect to a server.
     */
    public static class MaximumRetryExceeded extends AMPSException
    {
        private static final long serialVersionUID = 1L;
    }

    /**
     * The default delay when reconnecting to a server, in milliseconds.
     */
    public static final int DEFAULT_DELAY = 200;

    /**
     * Construct a FixedDelayStrategy with the default delay (200ms).
     */
    public FixedDelayStrategy()
    {
        this._delay = DEFAULT_DELAY;
        this._maximum = 0;
    }

    /**
     * Construct a FixedDelayStrategy with a specified delay.
     * @param delay_ The delay (milliseconds) to be used between reconnect
     *               attempts to the same server.
     */
    public FixedDelayStrategy(int delay_)
    {
        this._maximum = 0;
        if(delay_ < 0)
        {
            this._delay = DEFAULT_DELAY;
        }
        else
        {
            this._delay = delay_;
        }
    }

    /**
     * Construct a FixedDelayStrategy with a specified delay and maximum.
     * @param delay_   The delay (milliseconds) to be used between reconnect
     *                 attempts to the same server.
     * @param maximum_ The maximum time (milliseconds) to try connecting
     *                 to servers before "giving up."
     */
    public FixedDelayStrategy(int delay_, int maximum_)
    {
        this._maximum = maximum_;
        if(delay_ < 0)
        {
            this._delay = DEFAULT_DELAY;
        }
        else
        {
            this._delay = delay_;
        }
    }

    /**
     * Returns the time (in milliseconds) that the client should wait
     * before connecting to the given server URI.
     * @param uri_ The URI to which the client intends to connect.
     * @return Returns the time in milliseconds the client should
     * delay before connecting to uri_.
     * @throws Exception Any exception thrown indicates no connection
     * should be attempted.
     */
    public int getConnectWaitDuration(String uri_) throws Exception
    {
        int delay = 0;
        if(_lastUri == null || !_lastUri.equals(uri_))
        {
            // Do not wait to fail over; reconnect immediately.
            _lastUri = uri_;
            if(_firstUri != null && _firstUri.equals(uri_))
            {
                // We have wrapped around the "list" of servers. Delay.
                delay = _delay;
            }
            else if(_firstUri == null)
            {
                // This is the first time through. Mark uri_ as the first
                // of the assumed "list" of servers.
                _firstUri = uri_;
            }
        }
        else
        {
            // retrying the "same" server
            delay = _delay;
        }
        if(_maximum > 0)
        {
            long now = System.currentTimeMillis();
            if(_start > 0)
            {
                if (now-_start > _maximum+delay)
                {
                    throw new MaximumRetryExceeded();
                }
            }
            else
            {
                _start = now;
            }
        }
        return delay;
    }

    /**
     * Resets the state of this delay. AMPS calls this method when a
     * connection is successfully established.
     */
    public void reset()
    {
        _lastUri  = null;
        _firstUri = null;
        _start    = 0;
    }

    protected int    _delay;
    protected int    _maximum;
    protected long   _start;
    protected String _lastUri;
    protected String _firstUri;
}
