////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.util.Properties;
import java.nio.charset.Charset;

import com.crankuptheamps.client.exception.ProtocolException;

/**
* Implements the Protocol interface. Used to parse a byte stream as a series of messages.
* The byte stream must use the AMPS NVFIX protocol. 
*/
public class NVFIXProtocol extends FIXProtocol
{
    /**
     * Initializes a new NVFIXProtocol instance.
     */
    public NVFIXProtocol()
    {
        super();
    }

    /**
     * Initializes a new NVFIXProtocol instance with properties
     * @param props The properties to initialize the NVFIXProtocol.
     */
    public NVFIXProtocol(Properties props)
    {
        super(props);
    }

    /**
     * Initializes a new NVFIXProtocol instance with specified separators.
     * @param fieldSeparator The byte value representing the field separator.
     * @param headerSeparator The byte value representing the header separator.
     * @param messageSeparator The byte value representing the message separator.
     */
    public NVFIXProtocol(byte fieldSeparator,
                            byte headerSeparator,
                            byte messageSeparator)
    {
        super(fieldSeparator,headerSeparator,messageSeparator);
    }

    /**
     * Allocates a new NVFIX message.
     * @return The newly allocated NVFIX message.
     */
    public NVFIXMessage allocateMessage()
    {

        return new NVFIXMessage(this.fieldSeparator,
                                this.headerSeparator,
                                this.messageSeparator,
                                Charset.forName(CharsetName).newEncoder().onUnmappableCharacter(CodingErrorAction),
                                Charset.forName(CharsetName).newDecoder().onMalformedInput(CodingErrorAction));

    }

    /**
     * Gets the message stream for NVFIX protocol.
     * @return The message stream for NVFIX protocol.
     */
    public ProtocolParser getMessageStream()
    {
        return new NVFIXProtocolParser(this);
    }
}
