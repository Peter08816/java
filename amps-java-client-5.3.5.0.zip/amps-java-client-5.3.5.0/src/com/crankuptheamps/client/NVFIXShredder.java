////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.util.HashMap;
import java.util.Map;

/**
 * A parser class that converts a NVFIX message into a Java Map. 
 */
public final class NVFIXShredder
{
    final private byte fieldSeparator;

    /**
     * Initializes a new instance of the NVFIXShredder class with the
     * specified field separator.
     * @param fieldSeparator The byte used as the field separator in the NVFIX message.
     */
    public NVFIXShredder(byte fieldSeparator)
    {
        this.fieldSeparator = fieldSeparator;
    }

    /**
     * Converts an NVFIX message into a Dictionary.
     * @param fix The NVFIX message to be converted.
     * @return A Dictionary containing the parsed NVFIX message.
     */
    public Map<CharSequence, CharSequence> toNVMap(final String fix)
    {
        int index = 0;
        final int length = fix.length();
        final Map<CharSequence, CharSequence> map = new HashMap<CharSequence,CharSequence>(128);
        while(index < length - 1)
        {
            // First, read the tag
            final int endTag = fix.indexOf('=',index);
            final int endValue = fix.indexOf(this.fieldSeparator,endTag+1);
            map.put(fix.subSequence(index,endTag),
                    fix.subSequence(endTag+1,endValue));
            index = endValue + 1;
        }
        return map;
    }
}

