////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.CommandException;

import java.lang.Character;
import java.lang.Comparable;

/**
 * A representation of an AMPS version that can be compared.
 */
public class VersionInfo implements Comparable<VersionInfo>
{
    private String _versionString;
    private long _versionNum = 0;
    private long DEFAULT_VERSION_NUM = 9900990009900099L;
    private static int MAXVALUES = 4;
    private static int[] MAXDIGITS = new int[] { 4, 4, 5, 5 };

    public VersionInfo()
    {
        _versionString = "default";
    }

    public VersionInfo(String version_)
    {
        if (version_ == null || version_.isEmpty())
            _versionString = "default";
        else
            _versionString = version_;
    }

    public String getVersionString()
    {
        return _versionString;
    }

    public void setVersionString(String version_)
    {
        if (version_ == null || version_.isEmpty())
            _versionString = "default";
        else
            _versionString = version_;
        _versionNum = 0;
    }

    public long getVersion()
    {
        if (_versionNum == 0)
            parseVersion();
        return _versionNum;
    }

    public int getOldStyleVersion()
    {
        int version;
        try
        {
            version = Client.getVersionAsInt(_versionString);
        }
        catch (CommandException e)
        {
            version = 0;
        }
        if (version == 0)
            version = Message.MINIMUM_SERVER_VERSION;

        return version;
    }

    public int compareTo(VersionInfo other)
    {
        if (getVersion() < other.getVersion())
        {
            return -1;
        }
        else if (_versionNum > other._versionNum)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    public boolean equals(Object obj)
    {
        if (obj == null || !(obj instanceof VersionInfo))
            return false;
        VersionInfo other = (VersionInfo)obj;
        return getVersion() == other.getVersion();
    }

    public int hashCode()
    {
        return Long.valueOf(getVersion()).hashCode();
    }

    private void parseVersion()
    {
        if (!Character.isDigit(_versionString.charAt(0)))
        {
            _versionNum = DEFAULT_VERSION_NUM;
            return;
        }
        int digits = 0;
        int values = 0;
        long current = 0;
        char c;
        for (int i=0; i<_versionString.length(); ++i)
        {
            c = _versionString.charAt(i);
            if (Character.isDigit(c))
            {
                // If we exceed allowed digits, return default
                if (++digits > MAXDIGITS[values])
                {
                    _versionNum = DEFAULT_VERSION_NUM;
                    return;
                }
                current *= (long)10;
                current += (long)(c - '0');
            }
            else
            {
                if (c == '.')
                {
                    // Value complete, add current to _versionNum
                    _versionNum += current;
                    // Is that all the values?
                    if (++values >= MAXVALUES)
                        return;
                    // Make room for more
                    for (int j=0; j<MAXDIGITS[values]; ++j)
                    {
                        _versionNum *= (long)10;
                    }
                    digits = 0;
                    current = 0;
                }
                else // We got something odd, return default
                {
                    _versionNum = DEFAULT_VERSION_NUM;
                    return;
                }
            }
        }
        _versionNum += current;
        while (++values < MAXVALUES)
        {
            for (int i=0; i<MAXDIGITS[values]; ++i)
            {
                _versionNum *= (long)10;
            }
        }
        return;
    }
}

