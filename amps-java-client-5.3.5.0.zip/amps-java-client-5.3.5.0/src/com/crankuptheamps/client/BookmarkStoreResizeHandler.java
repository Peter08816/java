////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.Field;

/**
 * Interface used to indicate whether a BookmarkStore implementation is allowed
 * to grow (or shrink) to the requested size. If the request to resize is
 * denied, a BookmarkStore implementation may choose how to handle the
 * failure: if the bookmark for a message cannot be successfully logged,
 * an implementation may choose to throw an exception or may simply
 * retry the operation until space is available.
 */
public interface BookmarkStoreResizeHandler {
    /**
    * Called by the store when it wants to attempt a resize.
    *
    * @param store The store sending the resize request.
    * @param subId The id of the subscription that caused the resize request.
    * @param size  The new size the store would like to resize to.
    * @return A boolean indicating whether the store is allowed to resize or not.
    */
    public boolean invoke(BookmarkStore store, Field subId, long size);
}
