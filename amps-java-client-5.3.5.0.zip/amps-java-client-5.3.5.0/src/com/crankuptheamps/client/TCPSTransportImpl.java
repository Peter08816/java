///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.URI;
import java.beans.ExceptionListener;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedByInterruptException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.TimeUnit;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.List;
import java.util.Properties;
import javax.net.ssl.*;
import java.security.*;

import com.crankuptheamps.client.exception.AlreadyConnectedException;
import com.crankuptheamps.client.exception.ConnectionRefusedException;
import com.crankuptheamps.client.exception.DisconnectedException;
import com.crankuptheamps.client.exception.RetryOperationException;
import com.crankuptheamps.client.exception.InvalidURIException;

/**
 * The SSL Socket implementation of {@link TCPSTransport}. TCPS Transport delegates to an instance of this class. 
 * This is used internally by the client's transport. There is usually no reason to make direct use of it. 
 * Its functionality is best accessed via the client instance. 
 */
public class TCPSTransportImpl extends TCPTransportImpl
{
    /**
     * Constructs a new TCPSTransportImpl instance.
     * @param messageType  The protocol message type.
     * @param properties   The properties to configure the transport.
     * @param filter       The transport filter.
     */
    public TCPSTransportImpl(Protocol messageType, Properties properties, TransportFilter filter)
    {
        super(messageType,properties,filter);
    }

    /**
     * Initiates the SSL/TLS handshake on the underlying SSLSocket.
     * @throws Exception If an error occurs during the handshake process.
     */
    protected void handshake() throws Exception
    {
        ((SSLSocket)_socket).startHandshake();
        super.handshake();
    }

    /**
     * Creates a new SSLSocket for secure communication.
     * @return The created SSLSocket.
     * @throws Exception If an error occurs during socket creation.
     */
    protected Socket createSocket() throws Exception
    {
        SSLSocket s = (SSLSocket)TCPSTransport.getDefaultSSLContext()
                                .getSocketFactory().createSocket();
        String[] suites = TCPSTransport.getDefaultEnabledCipherSuites();
        if(suites != null)
        {
            s.setEnabledCipherSuites(suites);
        }

        String[] protocols = TCPSTransport.getDefaultEnabledProtocols();
        if(protocols != null)
        {
            s.setEnabledProtocols(protocols);
        }
        return s;
    }
    
    /**
     * Applies socket properties including Server Name Indication (SNI) if specified in the properties.
     * @param properties_ The properties to apply to the socket.
     * @throws SocketException      If an error occurs while configuring the socket.
     * @throws InvalidURIException If an invalid URI is encountered.
     */
    protected void applySocketProperties(Properties properties_)
      throws SocketException, InvalidURIException
    {
        if(properties_ == null) return;
        super.applySocketProperties(properties_);

        for(Map.Entry<Object, Object> entry : properties_.entrySet())
        {
            Object key = entry.getKey();
            Object value = entry.getValue();
            if("sni".equals(key))
            {
                String SNI = (String)value;
                SSLParameters sslParams = new SSLParameters();
                List<SNIServerName> serverNames = Collections.<SNIServerName>singletonList(new SNIHostName(SNI));
                sslParams.setServerNames(serverNames);
                ((SSLSocket)_socket).setSSLParameters(sslParams);
            }
        }
    }

}
