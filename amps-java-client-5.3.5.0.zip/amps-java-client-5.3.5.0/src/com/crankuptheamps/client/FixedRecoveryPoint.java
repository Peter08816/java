///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.BookmarkField;
import com.crankuptheamps.client.fields.Field;

/**
 * Interface to provide a recovery point for a bookmark subscription.
 * Used in the RecoveryPointAdapter interface for updates and recovery.
 */
class FixedRecoveryPoint implements RecoveryPoint {
    private Field _subId = null;
    private BookmarkField _bookmark = null;

    /**
     * Initializes a new instance of the FixedRecoveryPoint class.
     */
    public FixedRecoveryPoint() {
        _subId = new Field();
        _bookmark = new BookmarkField();
    }

    /**
     * Initializes a new instance of the FixedRecoveryPoint class with
     * the specified subscription ID and bookmark.
     * @param subId_     The subscription ID
     * @param bookmark_  The bookmark.
     */
    public FixedRecoveryPoint(Field subId_, BookmarkField bookmark_) {
        _subId = subId_;
        _bookmark = bookmark_;
    }

    /**
     * Return the subscription id for this recovery point
     */
    public Field getSubId() {
        return _subId;
    }

    /**
     * Return the bookmark for this recovery point
     */
    public BookmarkField getBookmark() {
        return _bookmark;
    }

    /**
     * Return a deep copy of self
     */
    public RecoveryPoint copy() {
        return new FixedRecoveryPoint(_subId.copy(), _bookmark.copy());
    }
}

