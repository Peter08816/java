////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2018-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

/**
 * Used to indicate the version of this client build outside of JAR manifest
 * files (which can be lost due to repackaging in cases such as "fat JARs").
 * The replacement tags in this file are substituted with real version numbers
 * (using the same source as the JAR manifest) just before compilation, then
 * substituted back to the replacement tags immediately afterward.
 */
public class ClientVersion {
    /**
     * The release version number of this AMPS client build. Usually
     * corresponds to the release branch name.<br><br>
     * 
     * WARNING: DO NOT COMMIT A VERSION OF THIS FILE THAT HAS A REAL VERSION
     * NUMBER HERE. THE SOURCE CODE SHOULD ALWAYS HAVE A REPLACEMENT TAG
     * SURROUNDED BY '@' CHARS FOR THIS VALUE.
     */
    public static final String RELEASE_VERSION = "5.3.5.0";

    /**
     * The implementation version number of this AMPS client build. Usually
     * corresponds to the release branch name followed by space, open paren,
     * branch HEAD commit hash, dot, build timestamp, close paren.<br><br>
     * 
     * WARNING: DO NOT COMMIT A VERSION OF THIS FILE THAT HAS A REAL VERSION
     * NUMBER HERE. THE SOURCE CODE SHOULD ALWAYS HAVE A REPLACEMENT TAG
     * SURROUNDED BY '@' CHARS FOR THIS VALUE.
     */
    public static final String IMPLEMENTATION_VERSION = "5.3.5.0.75de7c8a.712431.notmanifest";

    /**
     * Gets the release version number of this AMPS client build.
     * @return A string version of the version number.
     */
    public static String getReleaseVersion() {
        return RELEASE_VERSION;
    }

    /**
     * Gets the implementation version number of this AMPS client build.
     * @return A string version of the version number.
     */
    public static String getImplementationVersion() {
        return IMPLEMENTATION_VERSION;
    }
}
