////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.nio.ByteBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;

import com.crankuptheamps.client.fields.*;
import com.crankuptheamps.client.exception.*;

/**
 * All communication with AMPS occurs through passing Messages.
 * Generally when sending messages to AMPS an application we would
 * use {@link Command} API.
 * The AMPS clients provide named convenience methods for core AMPS
 * functionality. These named methods work by creating and sending
 * Messages to AMPS.
 */
public abstract class Message {
    // Not using enums here looks like Java 1.4 circa 2003.
    // That said, it's fast, low-cost, and safe enough if
    // guarded against mis-use (which we do.)
    /**
     * Tells AMPS how to interpret a message.
     * <br>
     * Without a command, AMPS will reject the message.
     * <br>
     * The relevancy or meaning of other Message fields like options
     * will depend upon the value of its command field.
     *
     */
    static public final class Command {
        public static final int Unknown = 0;
        public static final int Publish = 1;
        public static final int Subscribe = 2;
        public static final int Unsubscribe = 4;
        public static final int SOW = 8;
        public static final int Heartbeat = 16;
        public static final int SOWDelete = 32;
        public static final int DeltaPublish = 64;
        public static final int Logon = 128;
        public static final int SOWAndSubscribe = 256;
        public static final int DeltaSubscribe = 512;
        public static final int SOWAndDeltaSubscribe = 1024;
        public static final int StartTimer = 2048;
        public static final int StopTimer = 4096;
        public static final int GroupBegin = 8192;
        public static final int GroupEnd = 16384;
        public static final int OOF = 32768;
        public static final int Ack = 65536;
        public static final int Flush = 131072;
        public static final int NoDataCommands = Publish | Unsubscribe | Heartbeat | SOWDelete | DeltaPublish | Logon
                | StartTimer | StopTimer | Flush;
    }

    // These AckTypes are often combined for a single command
    // so we favor the int 'mask' versus a heavy EnumSet.
    /**
     * Container class of maskable ints that represent the available types of
     * Message acknowledgement.
     * <br>
     * 
     * @see com.crankuptheamps.client.Command#getAckType()
     * @see com.crankuptheamps.client.Command#setAckType(int)
     * @see com.crankuptheamps.client.Command#addAckType(int)
     * @see com.crankuptheamps.client.fields.AckTypeField
     */
    static public final class AckType {
        public static final int None = 0;
        public static final int Received = 1;
        public static final int Parsed = 2;
        public static final int Processed = 4;
        public static final int Persisted = 8;
        public static final int Completed = 16;
        public static final int Stats = 32;
    }

    /**
     * Container class of ints that represent the possible
     * values for Message status.
     * <br>
     * 
     * @see Message#getStatus()
     * @see Message#setStatus(int)
     */
    static public final class Status {
        public static final int None = 0;
        public static final int Success = 1;
        public static final int Failure = 2;
        public static final int Retry = 3;
    }

    /**
     * Container class of ints that represent the possible
     * values for Message reason.
     * <br>
     * 
     * @see Message#setReason(int)
     * @see Message#getReason()
     */
    static public final class Reason {
        /**
         * This is the default state, typically indicating no specific reason or a successful operation.
         */
        public static final int None = 0;
        /**
         * When a publish indicates that the message, as identified by the bookmark, is already present in 
         * this instance of AMPS.
         */
        public static final int Duplicate = 1;
        /**
         * Indicates a problem when the AMPS server reports that a filter could not be successfully processed.
         */
        public static final int BadFilter = 2;
        /**
         * Represents an issue with a regular expression used for topic filtering. OR
         * When the AMPS server reports that the regex provided as the topic for a subscription or query could
         * not be processed.
         */
        public static final int BadRegexTopic = 3;
        /**
         * Occurs when a client attempts to register a subscription that already exists.
         */
        public static final int SubscriptionAlreadyExists = 4;
        /**
         * Indicates that the data has been deleted.
         */
        public static final int Deleted = 5;
        /**
         * Used when data has exceeded its validity or expiration.
         */
        public static final int Expired = 6;
        /**
         * Signifies a successful match or operation.
         */
        public static final int Match = 7;
        /**
         * Indicates an issue when the AMPS server reports that the command requested is
         * not valid for the topic specified.
         */
        public static final int InvalidTopic = 8;
        /**
         * When an error occurs with the name of a client.
         */
        public static final int NameInUse = 9;
        /**
         * Represents authentication failure.
         */
        public static final int AuthFailure = 10;
        /**
         * Used when a user doesn't have permission to logon or use a specific topic or command.
         */
        public static final int NotEntitled = 11;
        /**
         * Using the default authenication module, which allows everything.
         */
        public static final int AuthDisabled = 12;
        /**
         * Represents an issue with a bookmark, which is a saved message positions. 
         */
        public static final int InvalidBookmark = 13;
        /**
         * Occurs when there is an issue with the specified ordering of messages.
         */
        public static final int InvalidOrderBy = 14;
        /**
         * When the specified subscription ID is already in use for this client.
         */
        public static final int SubidInUse = 15;
        /**
         * Occurs when there is no topic specified.
         */
        public static final int NoTopic = 16;
        /**
         * Indicates a failure during the login process.
         */
        public static final int LogonFailed = 17;
        /**
         * Signifies that a login is required to perform the operation.
         */
        public static final int LogonRequired = 18;
        /**
         * Indicates an issue with both the topic and the filter.
         */
        public static final int InvalidTopicOrFilter = 19;
        /**
         * Occurs when an invalid subscription ID is provided.
         */
        public static final int InvalidSubId = 20;
        /**
         * Indicates that neither a topic nor a filter is specified.
         */
        public static final int NoTopicOrFilter = 21;
        /**
         * Occurs when there is no client name provided.
         */
        public static final int NoClientName = 22;
        /**
         * Represents an issue with the storage of messages.
         */
        public static final int BadSowKey = 23;
        /**
         * Indicates that regular expression topics are not supported.
         */
        public static final int RegexTopicNotSupported = 24;
        /**
         * Occurs when there is a failure in storing messages.
         */
        public static final int SowStoreFailed = 25;
        /**
         * Signifies an error in parsing data.
         */
        public static final int ParseError = 26;
        /**
         * Used when an operation or feature is not supported.
         */
        public static final int NotSupported = 27;
        /**
         * Indicates a failure in transactional message storage.
         */
        public static final int TxStoreFailure = 28;
        /**
         * When the AMPS server reports that a filter could not be 
         * successfully processed.
         */
        public static final int DuplicateLogon = 29;
        /**
         * Represents a failure in transaction replay.
         */
        public static final int TxnReplayFailed = 30;
        /**
         * Occurs when a SOW query is canceled.
         */
        public static final int SowCanceled = 31;
        /**
         * Indicates issues with provided options.
         */
        public static final int InvalidOptions = 32;
        /**
         * Signifies an issue with the message type.
         */
        public static final int InvalidMessageType = 33;
        /**
         * Indicates that the requested order-by condition is too large.
         */
        public static final int OrderByTooLarge = 34;
        /**
         * Used when a message is rejected by a transport filter.
         */
        public static final int RejectedByTransportFilter = 35;
        /**
         * Represents an attempt to delete invalid state of the world.
         */
        public static final int SowDeleteInvalid = 36;
        /**
         * This might never be used. 
         */
        public static final int PublishFilterNoMatch = 37;
        /**
         * Used for other, unspecified reasons or states.
         */
        public static final int Other = 38;
    }

    /**
     * Represents the possible values for message options in an AMPS command.
     * Options in a message are combined into a comma-delimited list. Each of
     * these option values is comma-terminated, so they can be easily combined
     * by simple string concatenation. For example,
     * to provide the options OOF and NoEmpties to a SOW and Subscribe
     * command, you can use the following code:
     * 
     * <pre>
     * Command c = new Command("sow_and_subscribe")
     *         .setOptions(Message.Options.OOF +
     *                 Message.Options.NoEmpties)
     * // other parameters for command here
     * ;
     * </pre>
     *
     * For options that take a list of parameters, this class provides
     * convenience constructors to format the list.
     * 
     * @see Command#getOptions()
     * @see Command#setOptions(String)
     * @see Message#getOptions()
     * @see Message#setOptions(String)
     */
    static public final class Options {
        public static final String None = null;

        /**
         * Constant string for the <code>live</code> option.
         * which requests that a bookmark subscription should receive
         * messages <em>before</em> they are written to the transaction
         * log once replay is complete. This could potentially slightly 
         * reduce latency in some configurations, although subscriptions 
         * using this option increase the risk of inconsistent data in 
         * failover situations.
         *
         */
        public static final String Live = "live,";

        /**
         * Constant string for the <code>oof</code> (out of focus) option.
         * When used with a subscription, the <code>oof</code> option
         * requests notification messages when a message that previously
         * matched the subscription no longer matches the subscription.
         *
         */
        public static final String OOF = "oof,";

        /**
         * Constant string for the <code>replace</code> option.
         * When this option is provided on a command, AMPS updates
         * the existing subscription specified in the
         * 
         * <pre>
         * SubId
         * </pre>
         * 
         * for the
         * command rather than creating a new subscription.
         * See the <em>AMPS User Guide</em> for details.
         *
         */
        public static final String Replace = "replace,";

        /**
         * Constant string for the <code>no_empties</code> option.
         * When used with a delta subscription, this option
         * specifies that AMPS will not create a message to this
         * subscription when a publish happens that does not change the
         * value of any field in the message.
         *
         */
        public static final String NoEmpties = "no_empties,";

        /**
         * Constant string for the <code>send_keys</code> option.
         * This option is the current server default, and does not
         * need to be specified. When set, AMPS provides the
         * key fields for a message along with changed fields in
         * messages to a delta subscription.
         *
         */
        public static final String SendKeys = "send_keys,";

        /**
         * Constant string for the <code>timestamp</code> option.
         * When specified on a command, AMPS will include the
         * timestamp header on data messages sent in response
         * to that command.
         *
         */
        public static final String Timestamp = "timestamp,";

        /**
         * Constant string for the <code>no_sow_key</code> option.
         * When specified on a command, AMPS will not provide the
         * SOW key field on messages provided in response to the command.
         *
         */
        public static final String NoSowKey = "no_sowkey,";

        /**
         * Constant string for the <code>cancel</code> option, used
         * when acknowledging (<code>sow_delete</code>) a leased message
         * to return the message to the queue rather than acknowledging
         * the message as processed.
         *
         */
        public static final String Cancel = "cancel,";

        /**
         * Constant string for the <code>expire</code> option, used
         * when acknowledging (<code>sow_delete</code>) a leased message
         * to immediately expire the message from the queue rather than
         * acknowledging the message as processed.
         */
        public static final String Expire = "expire,";

        /**
         * Constant string for the <code>resume</code> option.
         * This option is to start a set of bookmark subscriptions
         * that have been entered in a paused state.
         * See the <em>AMPS User Guide</em> for details.
         *
         */
        public static final String Resume = "resume,";

        /**
         * Constant string for the <code>pause</code> option.
         * This option is used to group bookmark subscriptions so
         * that a set of independent subscriptions can be started simultaneously
         * and proceed through replay together, typically used for
         * testing or auditing purposes.
         * See the <em>AMPS User Guide</em> for details.
         *
         */
        public static final String Pause = "pause,";

        /**
         * Constant string for the <code>fully_durable</code> option.
         * This option specifies that a message will not be provided
         * to a bookmark replay until it has been acknowledged as
         * persisted by all synchronous replication destinations. The
         * option is used to provide increased repeatability of bookmark
         * subscriptions, although it may increase the latency for
         * current publishes to be delivered to the subscriber due to the persistence
         * requirement.
         *
         */
        public static final String FullyDurable = "fully_durable,";

        /**
         * Formats the <code>conflation</code> option for a command.
         * This option can be used with subscriptions to topics in the
         * State-of-the-World to request that AMPS conflate publishes
         * to the same record. This can reduce bandwidth and processing
         * requirements for the subscriber. If a large number
         * of subscribers will use the same <code>conflation</code>
         * setting for the same topic, consider configuring a
         * <code>ConflatedTopic</code> on the server.
         *
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param conflation the conflation interval
         * @return the formatted value
         */
        public static String Conflation(String conflation) {
            return String.format("conflation=%s,", conflation);
        }

        /**
         * Formats the <code>conflation_key</code> option for a command
         * that uses the <code>conflation</code> option.
         * This option can be used with subscriptions to topics in the
         * State-of-the-World to request that AMPS conflate publishes
         * to messages with a common value for a field or set of fields
         * that is <em>not</em> the key for the topic.
         *
         * This option must be used with the <code>conflation</code> option.
         *
         * @param conflationKey the field or fields to use as a conflation key
         * @return the formatted value
         */
        public static String ConflationKey(String conflationKey) {
            return String.format("conflation_key=%s,", conflationKey);
        }

        /**
         * Formats the <code>top_n</code> option for a command.
         * When this option is specified, AMPS will return the
         * specified number of messages from the results.
         * See the <em>AMPS Command Reference</em> for
         * details.
         *
         * @param topN the number of messages to return from the result set
         * @return the formatted value
         */
        public static String TopN(int topN) {
            return String.format("top_n=%d,", topN);
        }

        /**
         * Formats the <code>skip_n</code> option for a
         * <code>sow</code> or <code>sow_and_subscribe</code> command.
         * When this option is provided, AMPS will skip the specified
         * number of messages before returning the <code>top_n</code>
         * records specified. See the <em>AMPS Command Reference</em>
         * and the <em>Developer Guide</em> for details.
         *
         * @param skipN the number of results to skip before beginning to return results
         * @return the formatted value
         */
        public static String SkipN(int skipN) {
            return String.format("skip_n=%d,", skipN);
        }

        /**
         * Formats the <code>max_backlog</code> option for a command,
         * used when subscribing to a queue.
         * When consuming from a queue, this option sets the maximum
         * number of messages the client is willing to have outstanding
         * at a given time. (The actual number of messages provided
         * is determined by both this parameter and the server
         * configuration.) See the <em>AMPS User Guide</em> and the
         * <em>AMPS Command Reference</em> for details.
         *
         * @param maxBacklog the maximum number of messages to provide to this
         *                   subscription at a given time
         * @return the formatted value
         */
        public static String MaxBacklog(int maxBacklog) {
            return String.format("max_backlog=%d,", maxBacklog);
        }

        /**
         * Formats the <code>rate</code> option for a command,
         * used to slow down the rate of a bookmark replay.
         * When used with a bookmark replay, this option directs
         * AMPS to slow down the replay to approximately the rate
         * specified. See the <em>AMPS Command Reference</em> for
         * details.
         *
         * @param rate the requested rate limit for the bookmark replay
         * @return the formatted value
         */
        public static String Rate(String rate) {
            return String.format("rate=%s,", rate);
        }

        /**
         * Formats the <code>rate_max_gap</code> option for a
         * command, which can be used when a bookmark replay specifies
         * a relative <code>rate</code>. When used with a bookmark replay that
         * specifies a relative rate (for example, that the replay should be
         * slowed down to no more than <code>2X</code> the original publish
         * rate), this option sets the maximum amount of time for the replay
         * to go without producing a message. See the <em>AMPS User Guide</em>
         * for details.
         *
         * @param rateMaxGap the maximum amount of time without producing a message
         * @return the formatted value
         */
        public static String RateMaxGap(String rateMaxGap) {
            return String.format("rate_max_gap=%s,", rateMaxGap);
        }

        /**
         * Formats the <code>select</code> option for a subscription
         * or SOW query, which specifies the fields produced
         * in the delivered messages. This overload of the method expects
         * a string that contains a comma-delimited list of field directives.
         * 
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param selectList the list of fields to produce
         * @return the formatted value
         */
        public static String Select(String selectList) {
            return String.format("select=[%s],", selectList);
        }

        /**
         * Formats the <code>select</code> option for a subscription
         * or SOW query, which specifies the fields produced
         * in the delivered messages. This overload of the method expects a
         * {@link java.lang.Iterable} that contains individual field
         * directives. The method formats the field directives into a
         * comma-delimited list.
         *
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param selectList a list of fields to produce
         * @return the formatted value
         */
        public static String Select(Iterable<String> selectList) {
            StringBuilder builder = new StringBuilder();
            builder.append("select=[");
            for (String s : selectList) {
                builder.append(s);
                builder.append(',');
            }
            builder.setCharAt(builder.length() - 1, ']');
            builder.append(',');
            return builder.toString();
        }

        /**
         * Formats the <code>projection</code> option for an
         * aggregated subscription, which specifies the fields produced
         * by the aggregation. When this option is provided,
         * a <code>grouping</code> option must also be provided.
         * This overload of the method expects a string that
         * contains a comma-delimited list of projections.
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param projection the fields to produce
         * @return the formatted value
         */
        public static String Projection(String projection) {
            return String.format("projection=[%s],", projection);
        }

        /**
         * Formats the <code>projection</code> option for an
         * aggregated subscription, which specifies the fields produced
         * by the aggregation. When this option is provided,
         * a <code>grouping</code> option must also be provided.
         * This overload of the method expects a {@link java.lang.Iterable}
         * that contains individual field projections. The method
         * formats the field projections into a comma-delimited list.
         *
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param projection a list of fields to produce
         * @return the formatted value
         */
        public static String Projection(Iterable<String> projection) {
            StringBuilder builder = new StringBuilder();
            builder.append("projection=[");
            for (String s : projection) {
                builder.append(s);
                builder.append(',');
            }
            builder.setCharAt(builder.length() - 1, ']');
            builder.append(',');
            return builder.toString();
        }

        /**
         * Formats the <code>grouping</code> option for an
         * aggregated subscription, which specifies how to determine
         * which records to aggregate together. When this option is provided,
         * a <code>projection</code> option must also be provided.
         * This overload of the method expects a <code>String</code>
         * that contains a comma-delimited list of fields to group
         * by. See the <em>AMPS User Guide</em> for details.
         *
         * @param grouping the fields to group by
         * @return the formatted value
         */
        public static String Grouping(String grouping) {
            return String.format("grouping=[%s],", grouping);
        }

        /**
         * Formats the <code>grouping</code> option for an
         * aggregated subscription, which specifies how to determine
         * which records to aggregate together. When this option is provided,
         * a <code>projection</code> option must also be provided.
         * This overload of the method expects a {@link java.lang.Iterable}
         * that contains individual fields. This method formats the contents of
         * the <code>Iterable</code> into a comma-delimited list.
         * See the <em>AMPS User Guide</em> for details.
         *
         * @param grouping the list of fields to group by
         * @return the formatted value
         */
        public static String Grouping(Iterable<String> grouping) {
            StringBuilder builder = new StringBuilder();
            builder.append("grouping=[");
            for (String s : grouping) {
                builder.append(s);
                builder.append(',');
            }
            builder.setCharAt(builder.length() - 1, ']');
            builder.append(',');
            return builder.toString();
        }

        /**
         * Formats the <code>ack_conflation</code> interval for a logon command.
         * This option can be used to request that, for this connection,
         * the server return persisted acknowledgements for publishes more
         * frequently than the default <code>1s</code> interval. Notice that,
         * if the server replicates messages to other destinations, the
         * effective conflation interval may depend on the replication
         * configuration of this server and the replication configuration of
         * the destinations that this server replicates to: AMPS will not
         * provide a persisted acknowledgment for a message that
         * has not been properly acknowledged by the applicable
         * replication destinations.
         *
         * This option is only valid on a <code>logon</code> command.
         *
         * @param interval the interval at which to conflate persisted publish
         *                 acknowledgements for this connection
         * @return the formatted value
         */
        public static String AckConflationInterval(String interval) {
            return String.format("ack_conflation=%s,", interval);
        }

        /**
         * Formats the <code>bookmark_not_found</code> option for a bookmark 
         * subscription. This option is used to tell the server what to do if
         * the requested bookmark is not found in the transaction log.
         * Allowed values for the <code>action</code> parameter:
         * <code>now</code> This is the default behavior which starts the subscription with no repaly.
         * <code>epoch</code> Start the subscription at the oldest message in the transaction log.
         * <code>fail</code> Return a failure ack to the client and don't start the subscrption.
         *
         * @param action the action to take if the bookmark is not found
         * @return the formatted value
         */
        public static String BookmarkNotFound(String action) {
            return String.format("bookmark_not_found=%s,", action);
        }

        public static final String BookmarkNotFoundNow = "bookmark_not_found=now,";
        public static final String BookmarkNotFoundEpoch = "bookmark_not_found=epoch,";
        public static final String BookmarkNotFoundFail = "bookmark_not_found=fail,";
    }

    /**
     * Used by associated {@link com.crankuptheamps.client.fields.Field} classes
     * to encode byte data
     */
    protected final CharsetEncoder encoder;

    /**
     * Used by associated {@link com.crankuptheamps.client.fields.Field} classes
     * to decode byte data
     */
    protected final CharsetDecoder decoder;

    /**
     * Defines the lower bound for {@link #getVersionAsInt()}
     */
    static final int MINIMUM_SERVER_VERSION = 99999999;

    protected Message(CharsetEncoder encoder,
            CharsetDecoder decoder) {
        this.encoder = encoder;
        this.decoder = decoder;
    }

    /**
     * Returns the CharsetEncoder for this Message.
     * The encoder is used by the Message to encode the fields.
     * 
     * @return The CharsetEncoder for this Message.
     */
    public CharsetEncoder getEncoder() {
        return this.encoder;
    }

    /**
     * Returns the CharsetDecoder for this Message.
     * The decoder is used by the Message to decode the fields.
     * 
     * @return The CharsetDecoder for this Message.
     */
    public CharsetDecoder getDecoder() {
        return this.decoder;
    }

    /**
     * Private field to store the bookmark sequence number for this Message.
     * The _bookmarkSeqNo is used by bookmark stores to track Messages. It
     * represents the position or sequence number of the message within a data
     * stream. A bookmark store is responsible for maintaining information about the
     * last processed message by a consumer. It facilitates the ability of the
     * consumer to resume processing from the point where it left off, especially
     * after reconnecting to the system.
     */
    private long _bookmarkSeqNo = 0;

    /**
     * This field is only used internally by bookmark store implementations
     * to cache a tracking index for undiscarded messages, so they can be
     * looked up quickly when discarded for a bookmark subscription. There
     * is generally no reason for end-user applications to use this.
     * 
     * @param val The value to set as the new BookmarkSeqNo for this Message.
     */
    public void setBookmarkSeqNo(long val) {
        _bookmarkSeqNo = val;
    }

    /**
     * Returns the bookmark sequence number for this Message.
     * This field is only used internally by bookmark store implementations
     * to cache a tracking index for undiscarded messages, so they can be
     * looked up quickly when discarded for a bookmark subscription. There
     * is generally no reason for end-user applications to use this.
     * 
     * @return The bookmark sequence number for this Message.
     */
    public long getBookmarkSeqNo() {
        return _bookmarkSeqNo;
    }

    /**
     * Initially, _subscription does not reference any object; it is empty
     */
    private Subscription _subscription = null;

    /**
     * Sets the Subscription for this Message.
     * This field is only used internally by bookmark store implementations to
     * establish a link between a message and its corresponding subscription,
     * enabling the tracking of messages for delivery and acknowledgment.
     * 
     * @param subscription the subscription to set
     */
    public void setSubscription(Subscription subscription) {
        _subscription = subscription;
    }

    /**
     * Gets the Subscription for this Message.
     * This method is only used internally by bookmark store implementations to
     * access the subscription object for the message being tracked. This method
     * help identify which subscriber acknowledged the message.
     * 
     * @return The Subscription used for this Message.
     */
    public Subscription getSubscription() {
        return _subscription;
    }

    private byte[] buffer = null;

    /**
     * Sets the byte buffer used for this Message.
     * It is uncommon for applications to use this directly.
     * 
     * @param buffer the byte buffer to use for the Message.
     */
    public void setBuffer(byte[] buffer) {
        this.buffer = buffer;
    }

    /**
     * Gets the byte buffer used by the Message.
     * It is uncommon for applications to use this directly.
     * 
     * @return the raw byte buffer backing this Message object.
     */
    public byte[] getBuffer() {
        return this.buffer;
    }

    private int _rawBufferOffset = 0;

    /**
     * Sets the Offset into the byte buffer where this Message begins.
     * It is uncommon for applications to use this directly.
     * 
     * @param offset Offset of first byte of Message within the buffer.
     */
    public void setRawBufferOffset(int offset) {
        this._rawBufferOffset = offset;
    }

    /**
     * Gets the offset into the byte buffer where this Message begins.
     * It is uncommon for applications to use this directly.
     * 
     * @return Offset of first byte of Message within the buffer.
     */
    public int getRawBufferOffset() {
        return this._rawBufferOffset;
    }

    private int _rawBufferLength = 0;

    /**
     * Set the length of the Message within the byte buffer.
     * It is uncommon for applications to use this directly.
     * It indicates how many bytes the message occupies within the buffer.
     * This method is typically used by the library or code to set the message
     * length for outgoing messages.
     *
     * @param length The length of the Message within the buffer.
     */
    public void setRawBufferLength(int length) {
        this._rawBufferLength = length;
    }

    /**
     * Gets the length of the Message within the byte buffer.
     * It is uncommon for applications to use this directly.
     * 
     * @return Length of Message within the buffer.
     */
    public int getRawBufferLength() {
        return this._rawBufferLength;
    }

    /**
     * Returned by calls to {@link #serialize(ByteBuffer)}
     */
    public enum SerializationResult {
        OK, BufferTooSmall
    }

    /**
     * Serializes this message into the provided byte buffer at its current
     * position.
     *
     * @param buffer The byte buffer to write into.
     * @return A result enum that either indicates success or that the
     *         provided buffer doesn't have enough remaining space to hold
     *         the serialized representation of the message.
     */
    public abstract SerializationResult serialize(ByteBuffer buffer);

    /**
     * Resets all {@link Field} members to null.
     * 
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message reset() {
        for (Field f : _fields) {
            f.reset();
        }
        _bookmarkSeqNo = 0;
        _subscription = null;
        _ignoreAutoAck = false;
        return this;
    }

    protected final AckTypeField _AckType = new AckTypeField();

    /**
     * Returns the type of acknowledgement for an acknowledgement Message.
     * 
     * @return The AckType for this acknowledgement Message.
     */
    public int getAckType() {
        return _AckType.getValue();
    }

    /**
     * Returns the type of acknowledgement for an outgoing Message.
     * 
     * @return The AckType for an outgoing Message.
     */
    public int getAckTypeOutgoing() {
        if (_AckType.isNull())
            return AckType.None;
        int ackType = AckType.None;
        int len = 0;
        for (int start = _AckType.position; start <= _AckType.position + _AckType.length; ++start) {
            if (start == _AckType.position + _AckType.length ||
                    _AckType.buffer[start] == (byte) ',') {
                ackType |= AckTypeField.decodeAckType(_AckType.buffer, start - len, len);
                len = 0;
            } else
                ++len;
        }
        return ackType;
    }

    /**
     * Sets the type of acknowledgement for an acknowledgement Message.
     * 
     * @param v The value to set as the AckType for the acknowledgement Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setAckType(int v) {
        _AckType.setValue(v);
        return this;
    }

    /**
     * Sets the type of acknowledgement for an acknowledgement Message.
     * 
     * @param v The value to set as the AckType for the acknowledgement Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setAckType(String v) {
        _AckType.set(v.getBytes(StandardCharsets.ISO_8859_1));
        return this;
    }

    /**
     * Checks whether the AckType field is null.
     * 
     * @return True if AckType field is null, false if not.
     */
    public boolean isAckTypeNull() {
        return _AckType.isNull();
    }

    protected final IntegerField _BatchSize = new IntegerField();

    /**
     * Returns the BatchSize for this Message.
     * 
     * @return The BatchSize for this Message.
     */
    public int getBatchSize() {
        return _BatchSize.getValue();
    }

    /**
     * Sets the BatchSize for this Message.
     * 
     * @param v the batch size to set
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setBatchSize(int v) {
        _BatchSize.setValue(v);
        return this;
    }

    /**
     * Checks whether the BatchSize field is null.
     * 
     * @return True if the BatchSize field is null, false if not.
     */
    public boolean isBatchSizeNull() {
        return _BatchSize.isNull();
    }

    protected final BookmarkField _Bookmark = new BookmarkField();

    /**
     * Returns the AMPS Bookmark for this Message. The Bookmark is an
     * identifier assigned by AMPS to locate a Message in the transaction
     * log.
     * 
     * @return AMPS Bookmark for this Message.
     */
    public String getBookmark() {
        return _Bookmark.getValue(decoder);
    }

    /**
     * Gets the raw value for the AMPS Bookmark. The Bookmark is an identifier
     * assigned by AMPS to locate a Message in the transaction log.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw value for the AMPS Bookmark.
     */
    public BookmarkField getBookmarkRaw() {
        return _Bookmark;
    }

    /**
     * Sets the value for the AMPS Bookmark. The Bookmark is an identifier
     * assigned by AMPS to locate a Message in the transaction log. Setting
     * the Bookmark is used for commands that locate Messages in the log,
     * such as a Bookmark subscribe or historical SOW query. Setting the
     * bookmark on a publish Message has no effect.
     * 
     * @param v The string used to set the value of the AMPS Bookmark.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setBookmark(String v) {
        _Bookmark.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the value for the AMPS Bookmark. The Bookmark is an identifier
     * assigned by AMPS to locate a Message in the transaction log. Setting
     * the Bookmark is used for commands that locate Messages in the log,
     * such as a Bookmark subscribe or historical SOW query. Setting the
     * Bookmark on a publish Message has no effect.
     * 
     * @param buffer The buffer containing the value for the Bookmark.
     * @param offset The location at which the value begins.
     * @param length The length of the value in the buffer.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setBookmark(byte[] buffer, int offset, int length) {
        _Bookmark.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Bookmark field is null.
     * 
     * @return True if the Bookmark field is null, false if not.
     */
    public boolean isBookmarkNull() {
        return _Bookmark.isNull();
    }

    protected final StringField _ClientName = new StringField();

    /**
     * Gets the ClientName on this Message.
     * 
     * @return The decoded Client name for this Message.
     */
    public String getClientName() {
        return _ClientName.getValue(decoder);
    }

    /**
     * Gets the ClientName on this Message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw ClientName on this Message.
     */
    public Field getClientNameRaw() {
        return _ClientName;
    }

    /**
     * Sets the name of the Client sending the Message.
     * 
     * @param v The string used to set the ClientName.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setClientName(String v) {
        _ClientName.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the name of the Client sending the Message.
     * 
     * @param buffer The buffer containing the ClientName.
     * @param offset The location at which the ClientName begins.
     * @param length The length of the ClientName.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setClientName(byte[] buffer, int offset, int length) {
        _ClientName.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the ClientName field is null.
     * 
     * @return True if the ClientName field is null, false if not.
     */
    public boolean isClientNameNull() {
        return _ClientName.isNull();
    }

    protected final StringField _CommandId = new StringField();

    /**
     * Gets the CommandId on this Message. The CommandId is an identifier
     * set by the client that is used to correlate later Messages. For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe.
     * 
     * @return The decoded CommandId on this Message.
     */
    public String getCommandId() {
        return _CommandId.getValue(decoder);
    }

    /**
     * Gets the CommandId on this Message. The CommandId is an identifier
     * set by the client that is used to correlate later Messages. For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw CommandId on this Message.
     */
    public Field getCommandIdRaw() {
        return _CommandId;
    }

    /**
     * Gets the CommandId on this Message by copying it into the provided
     * CommandId object. The CommandId is an identifier
     * set by the client that is used to correlate later messages.
     * For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe. The CommandId is returned on
     * ack messages in response to the command.
     * 
     * @param v The object to hold the value of the CommandId object.
     * @return A copy of the message in the provided CommandId object.
     */
    public boolean getCommandId(CommandId v) {
        return _CommandId.getValue(v);
    }

    /**
     * Sets the CommandId on this Message. The CommandId is an identifier
     * set by the client that is used to correlate later messages and commands.
     * For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe. The CommandId is returned on
     * ack messages in response to the command.
     * 
     * @param v The string CommandId to set on this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCommandId(String v) {
        _CommandId.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the CommandId on this Message. The CommandId is an identifier
     * set by the client that is used to correlate later messages and commands.
     * For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe. The CommandId is returned on
     * ack messages in response to the command.
     * 
     * @param v The CommandId object to set on this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCommandId(CommandId v) {
        _CommandId.setValue(v);
        return this;
    }

    /**
     * Sets the CommandId on this Message. The CommandId is an identifier
     * set by the client that is used to correlate later messages and commands.
     * For example,
     * the client sets a CommandId on a subscription request to AMPS, and can
     * later use that CommandId to unsubscribe. The CommandId is returned on
     * ack messages in response to the command.
     * 
     * @param buffer The buffer containing the CommandId on this Message.
     * @param offset The location at which the CommandId begins.
     * @param length The length of the CommandId.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCommandId(byte[] buffer, int offset, int length) {
        _CommandId.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the CommandId is null.
     * 
     * @return True if the CommandId field is null, false if not.
     */
    public boolean isCommandIdNull() {
        return _CommandId.isNull();
    }

    protected final CommandField _Command = new CommandField();

    /**
     * Returns the Command for this Message, indicating the type of
     * of message this is. The fields that are supported by this message,
     * and how they are set and interpreted, depend on the type of message.
     * See the AMPS Command Reference for details.
     * 
     * @return The Command for this Message.
     */
    public int getCommand() {
        return _Command.getValue();
    }

    /**
     * Sets the Command for this Message, indicating the type of
     * of Message this is. The fields that are supported by this message,
     * and how they are set and interpreted, depend on the type of message.
     * See the AMPS Command Reference for details.
     * 
     * @param v The integer Command to set on this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCommand(int v) {
        _Command.setValue(v);
        return this;
    }

    /**
     * Sets the Command for this Message, indicating the type of
     * of Message this is. The fields that are supported by this message,
     * and how they are set and interpreted, depend on the type of message.
     * See the AMPS Command Reference for details.
     * 
     * @param v The Command to set on this Message. The value provided must
     *          be a value supported by the AMPS server, or the server will refuse
     *          to process the command.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCommand(String v) {
        _Command.set(v.getBytes(StandardCharsets.ISO_8859_1));
        return this;
    }

    /**
     * Checks whether the Command field is null.
     * 
     * @return True if the Command field is null, false if not.
     */
    public boolean isCommandNull() {
        return _Command.isNull();
    }

    protected final StringField _Data = new StringField();

    /**
     * Returns the payload of the Message.
     * 
     * @return The decoded payload for this Message.
     */
    public String getData() {
        return _Data.getValue(decoder);
    }

    /**
     * Returns the payload of the Message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw payload for this Message.
     */
    public Field getDataRaw() {
        return _Data;
    }

    /**
     * Sets the payload of the Message.
     * 
     * @param v The string to set as the payload of this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setData(String v) {
        _Data.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the payload of the Message.
     * 
     * @param buffer The buffer containing the Data.
     * @param offset The location at which the Data begins.
     * @param length The length of the data.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setData(byte[] buffer, int offset, int length) {
        _Data.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Data field is null.
     * 
     * @return True if the Data field is null, false if not.
     */
    public boolean isDataNull() {
        return _Data.isNull();
    }

    protected final IntegerField _Expiration = new IntegerField();

    /**
     * Returns the Expiration field set for this Message.
     * 
     * @return The Expiration for this Message.
     */
    public int getExpiration() {
        return _Expiration.getValue();
    }

    /**
     * Returns the Expiration field set for this Message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw Expiration for this Message.
     */
    public IntegerField getExpirationRaw() {
        return _Expiration;
    }

    /**
     * Sets the Expiration field for this Message.
     * The expiration is used on a publish command to set the lifetime
     * of a message. For the lifetime to be processed by AMPS, the
     * message must be published to a SOW topic that supports message
     * expiration. See the AMPS User Guide for details.
     * 
     * @param v The lifetime of the Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setExpiration(int v) {
        _Expiration.setValue(v);
        return this;
    }

    /**
     * Checks whether the Expiration field is null.
     * 
     * @return True if the Expiration field is null, false if not.
     */
    public boolean isExpirationNull() {
        return _Expiration.isNull();
    }

    protected final StringField _Filter = new StringField();

    /**
     * Returns the Filter field on this Message.
     * Filters are used for commands that provide content filtering,
     * such as SOW queries, subscriptions, and SOW delete.
     * 
     * @return The decoded Filter on this Message.
     */
    public String getFilter() {
        return _Filter.getValue(decoder);
    }

    /**
     * Returns the Filter field on this Message.
     * Filters are used for commands that provide content filtering,
     * such as SOW queries, subscriptions, and SOW delete.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw Filter on this Message.
     */
    public Field getFilterRaw() {
        return _Filter;
    }

    /**
     * Sets the Filter field on this Message.
     * Filters are used for commands that provide content filtering,
     * such as SOW queries, subscriptions, and SOW delete.
     * 
     * @param v The string to set as the Filter on this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setFilter(String v) {
        _Filter.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the Filter field on this Message.
     * Filters are used for commands that provide content filtering,
     * such as SOW queries, subscriptions, and SOW delete.
     * 
     * @param buffer The buffer containing the Filter for this Message.
     * @param offset The location at which the Filter begins.
     * @param length The length of the Filter.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setFilter(byte[] buffer, int offset, int length) {
        _Filter.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Filter field is null.
     * 
     * @return True if the Filter field is null, false if not.
     */
    public boolean isFilterNull() {
        return _Filter.isNull();
    }

    /**
     * set by the server messages on messages received from a queue
     * and indicates the point in time at which the server will break
     * the lease on the message if the message is still leased to the
     * subscription. During this time frame, the subscriber is granted
     * exclusive access to the message, allowing it to be processed or
     * acknowledged. If the message is not acknowledged within the
     * LeasePeriod, AMPS may take predefined actions, such as re-delivery
     * or error handling, to ensure message reliability and resource
     * efficiency.
     * LeasePeriods are often configurable to accommodate diverse use
     * cases and requirements: shorter periods for rapid processing
     * and recovery from subscriber failures while the longer ones for
     * extended tasks or deliberation.
     */
    protected final StringField _LeasePeriod = new StringField();

    /**
     * Check whether the LeasePeriod field is null.
     * 
     * @return true if LeasePeriod is null.
     */
    public boolean isLeasePeriodNull() {
        return _LeasePeriod.isNull();
    }

    /**
     * Gets the decoded version of the LeasePeriod for the Message.
     * 
     * @return Decoded LeasePeriod for the Message.
     */
    public String getLeasePeriod() {
        return _LeasePeriod.getValue(decoder);
    }

    /**
     * Gets the raw version of the LeasePeriod filter for the Message.
     * 
     * @return Raw LeasePeriod for the Message.
     */
    public StringField getLeasePeriodRaw() {
        return _LeasePeriod;
    }

    /**
     * this is only used for logon commands -- people sometimes try to
     * use multiple message types over a single connection by setting
     * message type, but that doesn't work.
     */
    protected final StringField _MessageType = new StringField();

    /**
     * Returns the MessageType field on this message.
     * When the client library produces a logon command, it uses
     * the MessageType field to specify the message type for the connection
     * when a message type is provided in the connection URI.
     * 
     * @return The MessageType on this message.
     */
    public String getMessageType() {
        return _MessageType.getValue(decoder);
    }

    /**
     * sets the MessageType field on this message. When the client library
     * produces a logon command, it uses the MessageType field to specify the
     * message type for the connection when a message type is provided in the
     * connection URI.
     * 
     * @param v The string MessageType to set on this message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setMessageType(String v) {
        _MessageType.setValue(v, encoder);
        return this;
    }

    /**
     * Checks whether the MessageType field is null.
     * 
     * @return True if MessageType field is null, false if not.
     */
    public boolean isMessageTypeNull() {
        return _MessageType.isNull();
    }

    protected final StringField _OrderBy = new StringField();

    /**
     * Get the OrderBy parameter for this Message.
     * For commands that support ordering, this parameter provides the
     * order in which AMPS returns results.
     * 
     * @return The decoded OrderBy parameter for this Message.
     */
    public String getOrderBy() {
        return _OrderBy.getValue(decoder);
    }

    /**
     * Get the OrderBy parameter for this Message.
     * For commands that support ordering, this parameter provides the
     * order in which AMPS returns results.
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw OrderBy parameter for this Message.
     */
    public Field getOrderByRaw() {
        return _OrderBy;
    }

    /**
     * Set the OrderBy parameter for this Message.
     * For commands that support ordering, this parameter provides the
     * order in which AMPS returns results. See the AMPS User Guide for
     * details.
     * 
     * @param v The ordering expression to set for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setOrderBy(String v) {
        _OrderBy.setValue(v, encoder);
        return this;
    }

    /**
     * Set the OrderBy parameter for this Message.
     * For commands that support ordering, this parameter provides the
     * order in which AMPS returns results. See the AMPS User Guide for
     * details.
     * 
     * @param buffer The buffer that contains the expression.
     * @param offset The location at which the expression begins.
     * @param length The length of the expression.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setOrderBy(byte[] buffer, int offset, int length) {
        _OrderBy.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the OrderBy field is null.
     * 
     * @return True if the OrderBy field is null, false if not.
     */
    public boolean isOrderByNull() {
        return _OrderBy.isNull();
    }

    /**
     * When executing a SOW query and AMPS returns a batch of query results,
     * this sequence number is set on each message within the result batch
     * to indicate it's position within the batch. Generally applications
     * do not need to use this.
     */
    protected final LongField _GroupSeqNo = new LongField();

    /**
     * When executing a SOW query and AMPS returns a batch of query results,
     * this sequence number is set on each message within the result batch
     * to indicate it's position within the batch. Generally applications
     * do not need to use this.
     * 
     * @return The group sequence number.
     */
    public long getGroupSeqNo() {
        return _GroupSeqNo.getValue();
    }

    /**
     * When executing a SOW query and AMPS returns a batch of query results,
     * this sequence number is set on each message within the result batch
     * to indicate it's position within the batch. Generally applications
     * do not need to use this.
     * 
     * @param v The number set as the group sequence number.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setGroupSeqNo(long v) {
        _GroupSeqNo.setValue(v);
        return this;
    }

    /**
     * Checks whether the GroupSeqNo field is null.
     * 
     * @return True if the GroupSeqNo field is null, false if not.
     */
    public boolean isGroupSeqNoNull() {
        return _GroupSeqNo.isNull();
    }

    protected final LongField _Matches = new LongField();

    /**
     * Returns the number of matches in the command this Message acknowledges.
     * This header is provided on an acknowledgement message that includes
     * information on the number of matches. See the AMPS Command Reference for
     * details.
     * 
     * @return The number of matches in the command this Message acknowledges.
     */
    public long getMatches() {
        return _Matches.getValue();
    }

    /**
     * Sets the matches field on this Message. This header is typically
     * provided by AMPS.
     * 
     * @param v The number to set as the Matches field in this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setMatches(long v) {
        _Matches.setValue(v);
        return this;
    }

    /**
     * Checks whether the Matches field is Null.
     * 
     * @return True if the Matches field is null, false if not.
     */
    public boolean isMatchesNull() {
        return _Matches.isNull();
    }

    protected final StringField _Password = new StringField();

    /**
     * Returns the Password set on the Message.
     * This field is typically used during the logon sequence.
     * 
     * @return The decoded Password set on specified Message.
     */
    public String getPassword() {
        return _Password.getValue(decoder);
    }

    /**
     * Returns the Password set on the Message.
     * This field is used during the logon sequence.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw Password set on this Message.
     */
    public Field getPasswordRaw() {
        return _Password;
    }

    /**
     * Set the Password on the Message.
     * This field is typically used during the logon sequence.
     * 
     * @param v The string Password to set.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setPassword(String v) {
        _Password.setValue(v, encoder);
        return this;
    }

    /**
     * Set the Password on the Message.
     * This field is typically used during the logon sequence.
     * 
     * @param buffer The buffer that contains the Password.
     * @param offset The location where the Password starts.
     * @param length The length of the Password.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setPassword(byte[] buffer, int offset, int length) {
        _Password.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Password field is null.
     * 
     * @return True if the Password field is null, false if not.
     */
    public boolean isPasswordNull() {
        return _Password.isNull();
    }

    protected final IntegerField _Length = new IntegerField();

    /**
     * Returns the Length of the Message.
     * 
     * @return Length of the message.
     */
    public int getLength() {
        return _Length.getValue();
    }

    /**
     * Sets the Length of the Message.
     * This field is typically set by the AMPS client API rather than
     * by application code.
     * 
     * @param v The value to be set as the Length of the Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setLength(int v) {
        _Length.setValue(v);
        return this;
    }

    /**
     * Checks whether the Length field is null.
     * 
     * @return True if the Length field of the Message is null, false if not.
     */
    public boolean isLengthNull() {
        return _Length.isNull();
    }

    protected final OptionsField _Options = new OptionsField();

    /**
     * Returns the Options to be set on this Message.
     * 
     * @return The decoded Options set on this Message.
     */
    public String getOptions() {
        return _Options.getValue(decoder);
    }

    /**
     * Returns the Options to be set on this Message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The decoded Options set on this Message.
     */
    public Field getOptionsRaw() {
        return _Options;
    }

    /**
     * Sets the Options for the Message.
     * Options are a comma-delimited list of parameters. The values accepted
     * for options depend on the command: see the AMPS Command Reference for
     * details.
     * 
     * @param v The string to be used as the Options for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setOptions(String v) {
        _Options.setValue(v, encoder);
        return this;
    }

    /**
     * Checks whether the Options field is null.
     * 
     * @return True if the Options field is null, false if not.
     */
    public boolean isOptionsNull() {
        return _Options.isNull();
    }

    protected final StringField _QueryId = new StringField();

    /**
     * Returns the QueryId for this Message.
     * The QueryId returned on a message is the CommandId of the command
     * that ran the query. For example, when sending a SOW command to AMPS,
     * messages returned in response to that command will have the QueryId
     * set to the CommandId of the SOW command.
     * 
     * @return The decoded QueryId for this Message.
     */
    public String getQueryId() {
        return _QueryId.getValue(decoder);
    }

    /**
     * Returns the QueryId for this Message.
     * The QueryId returned on a message is the CommandId of the command
     * that ran the query. For example, when sending a SOW command to AMPS,
     * messages returned in response to that command will have the QueryId
     * set to the CommandId of the SOW command.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw QueryId for this Message.
     */
    public Field getQueryIdRaw() {
        return _QueryId;
    }

    /**
     * Returns the QueryId for this Message by copying it into the provided
     * CommandId.
     * The QueryId returned on a message is the CommandId of the command
     * that ran the query. For example, when sending a SOW command to AMPS,
     * messages returned in response to that command will have the QueryId
     * set to the CommandId of the SOW command.
     * 
     * @param v The CommandId to be used to copy the QueryId.
     * @return true if a QueryId is set on this message, false otherwise
     */
    public boolean getQueryId(CommandId v) {
        return _QueryId.getValue(v);
    }

    /**
     * Sets the QueryId field for this Message.
     * Typically, the QueryId is set by the AMPS client on incoming messages.
     * 
     * @param v The string to be set as the QueryId for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setQueryId(String v) {
        _QueryId.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the QueryId field for this Message by copying it from a CommandId
     * object.
     * Typically, the QueryId is set for incoming messages by the AMPS client.
     * 
     * @param v The CommandId to be set as the QueryId for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setQueryId(CommandId v) {
        _QueryId.setValue(v);
        return this;
    }

    /**
     * Sets the QueryId for this Message.
     * Typically, the QueryId is set by the AMPS client on incoming messages.
     * 
     * @param buffer The buffer containing the QueryId.
     * @param offset The location in the buffer where the QueryId begins.
     * @param length The length of the QueryId to be set.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setQueryId(byte[] buffer, int offset, int length) {
        _QueryId.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the QueryId field is null.
     * 
     * @return True if the QueryId field is null, false if not.
     */
    public boolean isQueryIdNull() {
        return _QueryId.isNull();
    }

    protected final ReasonField _Reason = new ReasonField();

    /**
     * Returns the Reason value of this Message.
     * The reason is set on acknowledgement messages to provide more
     * information about the acknowledgement.
     * 
     * @return The value in the Reason field of this Message.
     */
    public int getReason() {
        return _Reason.getValue();
    }

    /**
     * Returns the Reason value of this Message.
     * Typically, the reason is set for incoming messages by the AMPS client.
     * 
     * @return The text from the Reason field of the Message.
     */
    public String getReasonText() {
        return _Reason.getText();
    }

    /**
     * Sets the Reason value of this Message.
     * Typically, the reason is set for incoming messages by the AMPS client.
     * 
     * @param v The Reason value to set for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setReason(int v) {
        _Reason.setValue(v);
        return this;
    }

    /**
     * Checks whether the Reason is null.
     * 
     * @return True if the Reason field of the message is null, false if not.
     */
    public boolean isReasonNull() {
        return _Reason.isNull();
    }

    protected final LongField _RecordsInserted = new LongField();

    /**
     * Returns the number of records inserted for the command that this Message
     * was produced in response to.
     * This header is provided on an acknowledgement message that includes
     * information on the number of records inserted. See the AMPS Command
     * Reference for details.
     * 
     * @return The number of records inserted for the command that produced this
     *         Message.
     */
    public long getRecordsInserted() {
        return _RecordsInserted.getValue();
    }

    /**
     * Returns the number of records inserted for the command that this Message
     * was produced in response to.
     * This header is provided on an acknowledgement message.
     * An application does not typically need to set this field.
     * See the AMPS Command Reference for details.
     * 
     * @param v The value to set as the RecordsInserted field of the Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setRecordsInserted(long v) {
        _RecordsInserted.setValue(v);
        return this;
    }

    /**
     * Checks whether the RecordsInserted field is null.
     * 
     * @return True if the RecordsInserted field is null, false if not.
     */
    public boolean isRecordsInsertedNull() {
        return _RecordsInserted.isNull();
    }

    protected final LongField _RecordsUpdated = new LongField();

    /**
     * Returns the number of records updated for the command that this Message
     * was produced in response to.
     * This header is provided on an acknowledgement message. See the
     * AMPS Command Reference for details.
     * 
     * @return Number of records updated for the command that this Message was
     *         produced for.
     */
    public long getRecordsUpdated() {
        return _RecordsUpdated.getValue();
    }

    /**
     * Sets the records updated header field.
     * This header is provided on an acknowledgement message.
     * An application does not typically need to set this field.
     * See the AMPS Command Reference for details.
     * 
     * @param v Value to set the RecordsUpdated field to.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setRecordsUpdated(long v) {
        _RecordsUpdated.setValue(v);
        return this;
    }

    /**
     * Checks whether the RecordsUpdated field is null.
     * 
     * @return True if the RecordsUpdated field is null, false if not.
     */
    public boolean isRecordsUpdatedNull() {
        return _RecordsUpdated.isNull();
    }

    protected final LongField _RecordsDeleted = new LongField();

    /**
     * Returns the number of records deleted for the command that this Message
     * was produced in response to.
     * This header is provided on an acknowledgement message. See the
     * AMPS Command Reference for details.
     * 
     * @return The number of RecordsDeleted for the command that this Message was
     *         produced for.
     */
    public long getRecordsDeleted() {
        return _RecordsDeleted.getValue();
    }

    /**
     * Sets the records deleted header field.
     * This header is provided on an acknowledgement message.
     * An application does not typically need to set this field.
     * See the AMPS Command Reference for details.
     * 
     * @param v Value to set as the RecordsDeleted field.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setRecordsDeleted(long v) {
        _RecordsDeleted.setValue(v);
        return this;
    }

    /**
     * Checks whether the RecordsDeleted field is null.
     * 
     * @return True if the RecordsDeleted field is null, false if not.
     */
    public boolean isRecordsDeletedNull() {
        return _RecordsDeleted.isNull();
    }

    protected final LongField _RecordsReturned = new LongField();

    /**
     * Returns the number of records returned for the command that this Message
     * was produced in response to.
     * This header is provided on an acknowledgement message. See the
     * AMPS Command Reference for details.
     * 
     * @return The number of RecordsReturned for the command that this Message was
     *         produced for.
     */
    public long getRecordsReturned() {
        return _RecordsReturned.getValue();
    }

    /**
     * Sets the records returned header field.
     * This header is provided on an acknowledgement message.
     * An application does not typically need to set this field.
     * See the AMPS Command Reference for details.
     * 
     * @param v Value to set as the RecordsReturn field.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setRecordsReturned(long v) {
        _RecordsReturned.setValue(v);
        return this;
    }

    /**
     * Checks whether the RecordsReturned field is null.
     * 
     * @return True if the RecordsReturned field is null, false if not.
     */
    public boolean isRecordsReturnedNull() {
        return _RecordsReturned.isNull();
    }

    protected final LongField _Sequence = new LongField();

    /**
     * Returns the sequence number for this Message.
     * On outgoing messages, this field is typically set by the AMPS client.
     * The sequence number is used by AMPS for duplicate detection. Each
     * combination of client name and sequence number should be a unique
     * message. In the response to a login, AMPS may return the last sequence
     * number received from a client to assist in recovery.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw sequence number for this Message.
     */
    public Field getSequenceRaw() {
        return _Sequence;
    }

    /**
     * Returns the sequence number for this Message.
     * On outgoing messages, this field is typically set by the AMPS client.
     * The sequence number is used by AMPS for duplicate detection. Each
     * combination of client name and sequence number should be a unique
     * message. In response to a logon, AMPS may return the last sequence
     * number received from a client to assist in recovery.
     * 
     * @return The decoded sequence number for this Message.
     */
    public long getSequence() {
        return _Sequence.getValue();
    }

    /**
     * Sets the sequence number for this Message.
     * This field is typically set by the AMPS client.
     * The AMPS client uses the sequence number in outgoing messages.
     * The sequence number is used by AMPS for duplicate detection. Each
     * combination of client name and sequence number should be a unique
     * message.
     * 
     * @param v The value to set as the sequence number for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSequence(long v) {
        _Sequence.setValue(v);
        return this;
    }

    /**
     * Checks whether the Sequence field is null.
     * 
     * @return True if the Sequence field is null, false if not.
     */
    public boolean isSequenceNull() {
        return _Sequence.isNull();
    }

    protected final StringField _SowKey = new StringField();

    /**
     * Returns the SowKey for this Message.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SowKey on each message.
     * 
     * @return The decoded SowKey for this Message.
     */
    public String getSowKey() {
        return _SowKey.getValue(decoder);
    }

    /**
     * Returns the SowKey for this Message.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SowKey on each message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw SowKey for this Message.
     */
    public Field getSowKeyRaw() {
        return _SowKey;
    }

    /**
     * Sets the SowKey for this Message.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * 
     * @param v The string to be used for the SowKey.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSowKey(String v) {
        _SowKey.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the SowKey for this Message.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * 
     * @param buffer The buffer that contains the SOW Key.
     * @param offset The location within the buffer where the SOW Key begins.
     * @param length The length of the SOW Key.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSowKey(byte[] buffer, int offset, int length) {
        _SowKey.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the SowKey field is null.
     * 
     * @return True if the SowKey field is null, false if not.
     */
    public boolean isSowKeyNull() {
        return _SowKey.isNull();
    }

    protected final StringField _SowKeys = new StringField();

    /**
     * Gets the set of SowKeys this message applies to.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * 
     * @return The decoded set of SowKeys this message applies to.
     */
    public String getSowKeys() {
        return _SowKeys.getValue(decoder);
    }

    /**
     * Gets the set of SowKeys this message applies to.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw SowKeys this message applies to.
     */
    public Field getSowKeysRaw() {
        return _SowKeys;
    }

    /**
     * Sets the set of SowKeys this message applies to, as a comma-delimited
     * list of identifiers.
     * This can be useful for commands that operate on multiple SOW records,
     * such as a sow_delete that specifies a set of keys to remove.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * 
     * @param v A comma-delimited list of identifiers to be set as the SowKeys that
     *          this message applies to.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSowKeys(String v) {
        _SowKeys.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the set of SowKeys this message applies to, as a comma-delimited
     * list of identifiers.
     * This can be useful for commands that operate on multiple SOW records,
     * such as a sow_delete that specifies a set of keys to remove.
     * The SowKey is an opaque identifier used to uniquely identify a
     * SOW record within AMPS. For messages received from a SOW, AMPS provides
     * the SOW key on each message.
     * 
     * @param buffer The buffer that contains the SOW Key.
     * @param offset The location within the buffer where the SOW Key begins.
     * @param length The length of the SOW Key.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSowKeys(byte[] buffer, int offset, int length) {
        _SowKeys.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the SowKeys field is null.
     * 
     * @return True if the SowKeys field is null, false if not.
     */
    public boolean isSowKeysNull() {
        return _SowKeys.isNull();
    }

    protected final StatusField _Status = new StatusField();

    /**
     * Returns the Status of this Message. This field is provided by AMPS
     * on acknowledgements to indicate the success or failure of the
     * command being acknowledged.
     * 
     * @return The Status of this Message.
     */
    public int getStatus() {
        return _Status.getValue();
    }

    /**
     * Sets the Status of this Message. This field is provided by AMPS
     * on acknowledgements to indicate the success or failure of the
     * command being acknowledged.
     * 
     * @param v The value to be set as the Status of the Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setStatus(int v) {
        _Status.setValue(v);
        return this;
    }

    protected final StringField _SubId = new StringField();

    /**
     * Gets the SubId of this Message.
     * The SubId is a reference to the CommandId of the command that
     * created the subscription.
     * 
     * @return The decoded SubId of this Message.
     */
    public String getSubId() {
        return _SubId.getValue(decoder);
    }

    /**
     * Gets the SubId of this Message.
     * The SubId is a reference to the CommandId of the command that
     * created the subscription.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw SubId of this Message.
     */
    public Field getSubIdRaw() {
        return _SubId;
    }

    /**
     * Gets the SubId of this Message by copying it into the provided CommandId.
     * The SubId is a reference to the CommandId of the command that
     * created the subscription.
     * 
     * @param v The CommandId into which to copy the SubId.
     * @return true if a SubId is set on this message, false otherwise
     */
    public boolean getSubId(CommandId v) {
        return _SubId.getValue(v);
    }

    /**
     * Sets the SubId of this Message.
     * The SubId is a reference to the CommandId of the command that
     * created the subscription.
     * 
     * @param v The string used to set the SubId of this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSubId(String v) {
        _SubId.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the SubId of this Message by copying it from a CommandId object.
     * The SubId is the CommandId of the command that
     * created the subscription. For example, to replace a subscription,
     * you provide the SubId of the subscription to be replaced with the
     * command that replaces the subscription.
     * 
     * @param v The CommandId to be set as the SubId for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSubId(CommandId v) {
        _SubId.setValue(v);
        return this;
    }

    /**
     * Sets the SubId of this Message.
     * The SubId is a reference to the CommandId of the command that
     * created the subscription. For example, messages returned for a
     * subscription contain the SubId of the subscription.
     * 
     * @param buffer The buffer that contains the SubId key.
     * @param offset The location within the buffer where the SubId begins.
     * @param length The length of the SubId.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSubId(byte[] buffer, int offset, int length) {
        _SubId.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the SubId field is null.
     * 
     * @return True if the SubId is null, false if not.
     */
    public boolean isSubIdNull() {
        return _SubId.isNull();
    }

    protected final StringField _SubIds = new StringField();

    /**
     * The set of SubIds for this Message. AMPS returns a SubId for each
     * subscription that matches the message as a comma-delimited list.
     * The SubId is the identifier provided when the subscription was
     * registered with AMPS.
     * 
     * @return The decoded set of SubIds for this Message.
     */
    public String getSubIds() {
        return _SubIds.getValue(decoder);
    }

    /**
     * The set of SubIds for this message. AMPS returns a SubId for each
     * subscription that matches the message as a comma-delimited list.
     * The SubId is the identifier provided when the subscription was
     * registered with AMPS.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw set of SubIds for this message.
     */
    public Field getSubIdsRaw() {
        return _SubIds;
    }

    /**
     * The set of SubIds for this message. AMPS returns a SubId for each
     * subscription that matches the message as a comma-delimited list.
     * The SubId is the identifier provided when the subscription was
     * registered with AMPS.
     * 
     * @param v The comma-delimited list to be set as the SubIds for this message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSubIds(String v) {
        _SubIds.setValue(v, encoder);
        return this;
    }

    /**
     * The set of SubIds for this message. AMPS returns a SubId for each
     * subscription that matches the message.
     * The SubId is the identifier provided when the subscription was
     * registered with AMPS.
     * 
     * @param buffer The buffer containing the SubIds for this message.
     * @param offset The location of where the SubIds begin.
     * @param length The length of the list of SubIds.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setSubIds(byte[] buffer, int offset, int length) {
        _SubIds.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the SubIds field is null.
     * 
     * @return True if the SubIds field is null, false if not.
     */
    public boolean isSubIdsNull() {
        return _SubIds.isNull();
    }

    protected final StringField _Timestamp = new StringField();

    /**
     * Returns the timestamp for this message, an ISO-8601 formatted string.
     * The timestamp is set by AMPS at the time that AMPS processes the message.
     * 
     * @return The Timestamp for this Message as an ISO-8601 formatted string.
     */
    public String getTimestamp() {
        return _Timestamp.getValue(decoder);
    }

    /**
     * Returns the timestamp for this message, an ISO-8601 formatted string.
     * The timestamp is set by AMPS at the time that AMPS processes
     * the message.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw Timestamp for this Message.
     */
    public Field getTimestampRaw() {
        return _Timestamp;
    }

    /**
     * Sets the Timestamp for this Message. The timestamp is set by AMPS
     * at the time that AMPS processes the message. There is generally no
     * need to set this field in your application.
     * 
     * @param v The string to set as the Timestamp for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTimestamp(String v) {
        _Timestamp.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the timestamp for this message. The timestamp is set by AMPS
     * at the time that AMPS processes the message. There is generally no
     * need to set this field in your application.
     * 
     * @param buffer the buffer that contains the timestamp
     * @param offset the location within the buffer where the timestamp begins
     * @param length the length of the timestamp
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTimestamp(byte[] buffer, int offset, int length) {
        _Timestamp.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Timestamp field is null.
     * 
     * @return True if the Timestamp field is null, false if not.
     */
    public boolean isTimestampNull() {
        return _Timestamp.isNull();
    }

    protected final LongField _TopN = new LongField();

    /**
     * Get the TopN parameter for this message.
     * For commands that support limiting the number of messages in the result
     * set, this parameter provides the limit to AMPS.
     * 
     * @return The TopN parameter for this Message.
     */
    public long getTopN() {
        return _TopN.getValue();
    }

    /**
     * Set the TopN parameter for this message.
     * For commands that support limiting the number of messages in the result
     * set, this parameter provides the limit to AMPS.
     * 
     * @param v The value to be set as the TopN parameter.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTopN(long v) {
        _TopN.setValue(v);
        return this;
    }

    /**
     * Checks whether the TopN field is null.
     * 
     * @return True if the TopN field is null, false if not.
     */
    public boolean isTopNNull() {
        return _TopN.isNull();
    }

    protected final StringField _Topic = new StringField();

    /**
     * Return the topic that the message applies to.
     * 
     * @return The decoded Topic that the Message applies to.
     */
    public String getTopic() {
        return _Topic.getValue(decoder);
    }

    /**
     * Return the topic that the message applies to.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw Topic that the Message applies to.
     */
    public Field getTopicRaw() {
        return _Topic;
    }

    /**
     * Set the topic that the message applies to.
     * 
     * @param v The string to be set as the Topic that the Message applies to.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTopic(String v) {
        _Topic.setValue(v, encoder);
        return this;
    }

    /**
     * Set the topic that the message applies to.
     * 
     * @param buffer the buffer that contains the Topic
     * @param offset the location within the buffer where the Topic begins
     * @param length the length of the Topic
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTopic(byte[] buffer, int offset, int length) {
        _Topic.setValue(buffer, offset, length);
        return this;
    }

    /**
     * Checks whether the Topic field is null.
     * 
     * @return True if the Topic field is null, false if not.
     */
    public boolean isTopicNull() {
        return _Topic.isNull();
    }

    protected final LongField _TopicMatches = new LongField();

    /**
     * Returns the number of matching topics for the command that this message
     * was produced in response to.
     * This header is provided on an acknowledgement message that includes
     * information on the number of records inserted. See the AMPS Command
     * Reference for details.
     * 
     * @return The number of matching topics for the command that this Message was
     *         produced in response to.
     */
    public long getTopicMatches() {
        return _TopicMatches.getValue();
    }

    /**
     * Checks whether the TopicMatches field is null.
     * 
     * @return True if the TopicMatches field is null, false if not.
     */
    public boolean isTopicMatchesNull() {
        return _TopicMatches.isNull();
    }

    /**
     * Sets the topic matches field on this message. This header is typically
     * provided by AMPS.
     * 
     * @param v The value to set as the TopicMatches field on this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setTopicMatches(long v) {
        _TopicMatches.setValue(v);
        return this;
    }

    protected final StringField _UserId = new StringField();

    /**
     * Get the UserId for this message. This field is typically set during
     * the logon sequence. The field may also be provided on published
     * messages, depending on the authentication used in AMPS. When provided
     * on a published message, AMPS provides the identity of the connection
     * that sent the message, not the value provided with the message
     * as published.
     * 
     * @return The decoded UserId for this message.
     */
    public String getUserId() {
        return _UserId.getValue(decoder);
    }

    /**
     * Checks whether the UserId field is null.
     * 
     * @return True if the UserId field is null, false if not.
     */
    public boolean isUserIdNull() {
        return _UserId.isNull();
    }

    /**
     * Get the UserId for this message. This field is typically set during
     * the logon sequence. The field may also be provided on published
     * messages, depending on the authentication used in AMPS. When provided
     * on a published message, AMPS provides the identity of the connection
     * that sent the message, not the value provided with the message
     * as published.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw UserId for this Message.
     */
    public Field getUserIdRaw() {
        return _UserId;
    }

    /**
     * Set the UserId for this message. This field is typically set during
     * the logon sequence. The field may also be provided on published
     * messages, depending on the authentication used in AMPS. When provided
     * on a published message, AMPS provides the identity of the connection
     * that sent the message, not the value provided with the message
     * as published. Therefore, applications generally only set this
     * value during logon.
     * 
     * @param v The string to be set as the UserId for this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setUserId(String v) {
        _UserId.setValue(v, encoder);
        return this;
    }

    /**
     * Set the UserId for this message. This field is typically set during
     * the logon sequence. The field may also be provided on published
     * messages, depending on the authentication used in AMPS. When provided
     * on a published message, AMPS provides the identity of the connection
     * that sent the message, not the value provided with the message
     * as published. Therefore, applications generally only set this
     * value during logon.
     * 
     * @param buffer the buffer that contains the UserId
     * @param offset the position where the UserId begins
     * @param length the length of the UserId
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setUserId(byte[] buffer, int offset, int length) {
        _UserId.setValue(buffer, offset, length);
        return this;
    }

    protected final StringField _Version = new StringField();

    /**
     * Returns the version of the AMPS server, provided in response to a logon.
     * 
     * @return The decoded version of the AMPS server.
     */
    public String getVersion() {
        return _Version.getValue(decoder);
    }

    /**
     * Returns the version of the AMPS server, provided in response to a logon.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw version of the AMPS server.
     */
    public Field getVersionRaw() {
        return _Version;
    }

    /**
     * Checks whether the Version field is null.
     * 
     * @return True if the Version field is null, false if not.
     */
    public boolean isVersionNull() {
        return _Version.isNull();
    }

    /**
     * Returns the version of the AMPS server, provided in response to a logon.
     * 
     * @return The version of AMPS server.
     */
    public int getVersionAsInt() {
        // No version is 0
        if (_Version.isNull())
            return 0;

        int version;
        try {
            version = Client.getVersionAsInt(_Version.getValue(decoder));
        } catch (CommandException e) {
            version = 0;
        }
        if (version == 0)
            version = MINIMUM_SERVER_VERSION;

        return version;
    }

    /**
     * Sets the version field of this message. This is typically done by
     * the AMPS client API when a message with this field set is received.
     * 
     * @param v The string used to set the Version field of this Message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setVersion(String v) {
        _Version.setValue(v, encoder);
        return this;
    }

    /**
     * Sets the version field of this message. This is typically done by
     * the AMPS client API when a message with this field set is received.
     * 
     * @param buffer the buffer that contains the version string
     * @param offset the position where the version string begins
     * @param length the length of the version string
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setVersion(byte[] buffer, int offset, int length) {
        _Version.setValue(buffer, offset, length);
        return this;
    }

    protected final StringField _CorrelationId = new StringField();

    /**
     * Set the CorrelationId on this message. The CorrelationId
     * is an opaque identifier provided by the publisher of a message.
     * AMPS provides the identifier to subscribers of the message without
     * interpreting or changing the identifier. The CorrelationId may only
     * contain characters that are valid in base-64 encoding.
     * Base-64 encoding uses a subset of characters, typically consisting of
     * uppercase letters (A-Z), lowercase letters (a-z), digits (0-9), and two
     * additional characters, usually '+' and '/'.
     * 
     * @param v The string used to set the CorrelationId on this message.
     * @return Returns this instance so that various operations can be chained
     *         together.
     */
    public Message setCorrelationId(String v) {
        _CorrelationId.setValue(v, encoder);
        return this;
    }

    /**
     * Get the CorrelationId on this message. The CorrelationId
     * is an opaque identifier provided by the publisher of a message.
     * AMPS provides the identifier to subscribers of the message without
     * interpreting or changing the identifier.
     * 
     * @return The decoded version of the CorrelationId on this Message.
     */
    public String getCorrelationId() {
        return _CorrelationId.getValue(decoder);
    }

    /**
     * Get the CorrelationId on this message. The CorrelationId
     * is an opaque identifier provided by the publisher of a message.
     * AMPS provides the identifier to subscribers of the message without
     * interpreting or changing the identifier.
     * <br>
     * The Raw variation of this getter allows for finer-grained performance tuning.
     * It provides direct access to the {@link Field} that encapsulates the data.
     * <br>
     * This does not incur any additional heap allocation or unnecessary decoding
     * of the byte[] in which the data is stored. The lifetime of the
     * underlying buffer for the field is the lifetime of the Message.
     * If you need the data to persist longer than the lifetime of the
     * Message, you must copy the {@link Field}.
     * 
     * @return The raw CorrelationId on this Message.
     */
    public StringField getCorrelationIdRaw() {
        return _CorrelationId;
    }

    /**
     * Checks whether the CorrelationId field is null.
     * 
     * @return True if the CorrelationId field is null, false if not.
     */
    public boolean isCorrelationIdNull() {
        return _CorrelationId.isNull();
    }

    private final Object[][] _toStringFields = new Object[][] {
            { "Command", }
    };

    /**
     * Return the message as a string. This serializes the message and returns
     * the serialized value.
     * 
     * @return The Message as a serialized value.
     */
    public String toString() {
        StringBuilder s = new StringBuilder(1024);
        s.append("Message{");

        s.append("Command=").append(CommandField.encodeCommand(getCommand())).append("; ");
        if (!_AckType.isNull())
            s.append("AckType=").append(_AckType).append("; ");

        if (!_BatchSize.isNull())
            s.append("BatchSize=").append(getBatchSize()).append("; ");

        if (!_Bookmark.isNull())
            s.append("Bookmark=").append(getBookmark()).append("; ");

        if (!_ClientName.isNull())
            s.append("ClientName=").append(getClientName()).append("; ");

        if (!_CommandId.isNull())
            s.append("CommandId=").append(getCommandId()).append("; ");

        if (!_Expiration.isNull())
            s.append("Expiration=").append(getExpiration()).append("; ");

        if (!_Filter.isNull())
            s.append("Filter=").append(getFilter()).append("; ");

        if (!_LeasePeriod.isNull())
            s.append("LeasePeriod=").append(getLeasePeriod()).append("; ");

        if (!_OrderBy.isNull())
            s.append("OrderBy=").append(getOrderBy()).append("; ");

        if (!_GroupSeqNo.isNull())
            s.append("GroupSeqNo=").append(getGroupSeqNo()).append("; ");

        if (!_Matches.isNull())
            s.append("Matches=").append(getMatches()).append("; ");

        if (!_MessageType.isNull())
            s.append("MessageType=").append(getMessageType()).append("; ");

        if (!_Length.isNull())
            s.append("Length=").append(getLength()).append("; ");

        if (!_Options.isNull())
            s.append("Options=").append(getOptions()).append("; ");

        if (!_Password.isNull())
            s.append("Password=").append(getPassword()).append("; ");

        if (!_QueryId.isNull())
            s.append("QueryId=").append(getQueryId()).append("; ");

        if (!_Reason.isNull())
            s.append("Reason=").append(ReasonField.encodeReason(getReason())).append("; ");

        if (!_RecordsUpdated.isNull())
            s.append("RecordsUpdated=").append(getRecordsUpdated()).append("; ");

        if (!_RecordsInserted.isNull())
            s.append("RecordsInserted=").append(getRecordsInserted()).append("; ");

        if (!_RecordsReturned.isNull())
            s.append("RecordsReturned=").append(getRecordsReturned()).append("; ");

        if (!_RecordsDeleted.isNull())
            s.append("RecordsDeleted=").append(getRecordsDeleted()).append("; ");

        if (!_Sequence.isNull())
            s.append("Sequence=").append(getSequence()).append("; ");

        if (!_SowKey.isNull())
            s.append("SowKey=").append(getSowKey()).append("; ");

        if (!_SowKeys.isNull())
            s.append("SowKeys=").append(getSowKeys()).append("; ");

        if (!_Status.isNull())
            s.append("Status=").append(StatusField.encodeStatus(getStatus())).append("; ");

        if (!_SubId.isNull())
            s.append("SubId=").append(getSubId()).append("; ");

        if (!_SubIds.isNull())
            s.append("SubIds=").append(getSubIds()).append("; ");

        if (!_Timestamp.isNull())
            s.append("Timestamp=").append(getTimestamp()).append("; ");

        if (!_TopN.isNull())
            s.append("TopN=").append(getTopN()).append("; ");

        if (!_Topic.isNull())
            s.append("Topic=").append(getTopic()).append("; ");

        if (!_TopicMatches.isNull())
            s.append("TopicMatches=").append(getTopicMatches()).append("; ");

        if (!_CorrelationId.isNull())
            s.append("CorrelationId=").append(getCorrelationId()).append("; ");

        if (!_UserId.isNull())
            s.append("UserId=").append(getUserId()).append("; ");

        if (!_Data.isNull())
            s.append("Data=").append(getData()).append("; ");

        s.append('}');

        return s.toString();
    }

    public abstract Message copy();

    protected Client _client = null;

    /**
     * Returns the client who allocated this message.
     * 
     * @return A {@link com.crankuptheamps.client.Client} instance.
     */
    public Client getClient() {
        return _client;
    }

    /**
     * Used to acknowledge a queue message is processed.
     * 
     * @throws AMPSException An error occurred sending this acknowledgement to AMPS.
     */
    public void ack() throws AMPSException {
        if (_client != null && (!_client.getAutoAck() || _ignoreAutoAck)) {
            _client._ack(_Topic.buffer, _Topic.position, _Topic.length,
                    _Bookmark.buffer, _Bookmark.position, _Bookmark.length,
                    null, 0, 0);
        }
    }

    /**
     * Used to acknowledge a queue message is processed.
     * 
     * @param options    The bytes of the options for the ack
     * @param optionsPos The starting position in options
     * @param optionsLen The length of the options
     * @throws AMPSException An error occurred sending this acknowledgement to AMPS.
     */
    public void ack(byte[] options, int optionsPos, int optionsLen) throws AMPSException {
        if (_client != null && (!_client.getAutoAck() || _ignoreAutoAck)) {
            _client._ack(_Topic.buffer, _Topic.position, _Topic.length,
                    _Bookmark.buffer, _Bookmark.position, _Bookmark.length,
                    options, optionsPos, optionsLen);
        }
    }

    /**
     * Used to acknowledge a queue message is processed.
     * 
     * @param options The options to include with the ack.
     * @throws AMPSException An error occurred sending this acknowledgement to AMPS.
     */
    public void ack(Field options) throws AMPSException {
        if (_client != null && (!_client.getAutoAck() || _ignoreAutoAck)) {
            _client._ack(_Topic, _Bookmark, options);
        }
    }

    /**
     * Used to acknowledge a queue message is processed.
     * 
     * @param options The options to include with the ack.
     * @throws AMPSException An error occurred sending this acknowledgement to AMPS.
     */
    public void ack(String options) throws AMPSException {
        if (_client != null && (!_client.getAutoAck() || _ignoreAutoAck)) {
            _client._ack(_Topic, _Bookmark, new Field(options));
        }
    }

    private boolean _ignoreAutoAck = false;

    /**
     * Used to check if automatic acking of this Message by the Client
     * should be skipped.
     * 
     * @return If automatic acking is ignored for this Message.
     */
    public boolean isIgnoreAutoAck() {
        return _ignoreAutoAck;
    }

    /**
     * Used to disable automatic acking of this Message by the Client
     * after the {@link com.crankuptheamps.client.MessageHandler} completes.
     */
    public void setIgnoreAutoAck() {
        _ignoreAutoAck = true;
    }

    /**
     * Overwrites destination data with this Message.
     * <br>
     * Every field of destination is overwritten with this Message's data, though
     * destination retains the encoder and decoder it was originally constructed
     * with.
     * 
     * @param destination overwritten with this Message's data.
     */
    protected void _copyTo(Message destination) {
        destination._ignoreAutoAck = _ignoreAutoAck;
        destination._rawBufferLength = _rawBufferLength;
        destination._rawBufferOffset = 0;
        // If using buffer, copy the relevant portion
        if (this.buffer != null) {
            destination.buffer = new byte[_rawBufferLength];
            System.arraycopy(buffer, _rawBufferOffset, destination.buffer, 0, _rawBufferLength);
        }
        for (int i = 0; i < _fields.length; ++i) {
            // If in buffer, set there
            if (this.buffer != null && _fields[i].buffer == this.buffer) {
                final Field f = _fields[i];
                destination._fields[i].set(destination.buffer, f.position - _rawBufferOffset, f.length);
            } else { // Set as a copy
                destination._fields[i].copyFrom(_fields[i]);
            }
        }
        destination._bookmarkSeqNo = _bookmarkSeqNo;
        destination._subscription = _subscription;
        destination._client = _client;
    }

    /**
     * Need to visit every Field? Use this!
     */
    protected final Field[] _fields = new Field[] {
            _AckType,
            _BatchSize,
            _Bookmark,
            _ClientName,
            _CommandId,
            _Command,
            _CorrelationId,
            _Data,
            _Expiration,
            _Filter,
            _OrderBy,
            _GroupSeqNo,
            _Length,
            _LeasePeriod,
            _Matches,
            _MessageType,
            _Options,
            _QueryId,
            _Reason,
            _RecordsInserted,
            _RecordsUpdated,
            _RecordsDeleted,
            _RecordsReturned,
            _Sequence,
            _SowKey,
            _SowKeys,
            _Status,
            _SubId,
            _SubIds,
            _Timestamp,
            _TopN,
            _Topic,
            _TopicMatches,
            _UserId,
            _Version,
            _Password,
    };

}
