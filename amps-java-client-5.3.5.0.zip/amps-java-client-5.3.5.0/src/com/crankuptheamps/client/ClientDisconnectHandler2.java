////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

/**
 * 60East recommends using the HAClient, which includes a robust implementation of disconnect handling
 * and reconnection, unless your application has needs that cannot be met by the HAClient behavior.
 *
 * If you must use this interface, your implementation class must implement both
 * {@link ClientDisconnectHandler} and {@link ClientDisconnectHandler2}, so that it will
 * be accepted by {@link Client#setDisconnectHandler(ClientDisconnectHandler)}.
 * The method from this interface can be used to obtain the exception that caused the client to disconnect.
 */
public interface ClientDisconnectHandler2
{
    /**
     * When the Client unintentionally disconnects from AMPS, this method is
     * invoked.
     * @param client The client that unintentionally disconnected from AMPS.
     * @param e The exception thrown when the client unintentionally disconnected.
     */

    public void invoke(Client client, Exception e);
}
