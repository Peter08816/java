///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.Field;
import com.crankuptheamps.client.fields.BookmarkField;

/**
 * Interface used by {@link RecoveryPointAdapter}'s to represent a bookmark
 * subscription's recovery state, to allow that subscription to be resumed
 * in a reasonable place when the subscriber application exits and restarts.
 * This is typically a representation for one or more bookmarks, similar to
 * the MOST_RECENT state of a bookmark store that's used for resuming replays.
 * 
 * Implementations of this interface may contain a snapshot of recovery state
 * or may be lazily evaluated, such that they return the associated bookmark
 * store's current recovery state for the specified subscription id.
 */
public interface RecoveryPoint {
    /**
     * Returns the subscription id that this recovery point belongs to.
     *
     * @return The Field representing the subId.
     */
    Field getSubId();

    /**
     * Returns the subscription's recovery bookmark state.
     *
     * @return The BookmarkField representing the most recent for the subId.
     */
    BookmarkField getBookmark();

    /**
     * Creates and returns a deep copy of self.
     * @return A deep copy of the RecoveryPoint.
     */
    RecoveryPoint copy();
}
