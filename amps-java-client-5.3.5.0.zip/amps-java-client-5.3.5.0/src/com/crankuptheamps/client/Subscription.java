////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.CommandException;
import com.crankuptheamps.client.fields.BookmarkField;
import com.crankuptheamps.client.fields.BookmarkRangeField;
import com.crankuptheamps.client.fields.Field;

/**
* Interface that represents a single subscription within a bookmark store
* implementation. This can aid in creating your own implementation of
* {@link BookmarkStore}. If you feel that your requirements warrant
* creating a customized bookmark store implementation, please contact
* AMPS support for further advice.
*
* <pre>
* <code>
* public static void main(String[] args) {
*
*   try (HAClient client = new HAClient("subscribeExample");) {
*
*      DefaultServerChooser sc = new DefaultServerChooser();
*      sc.add(uri_);
*      client.setServerChooser(sc);
*
*      RingBookmarkStore bs = new RingBookmarkStore("bookmarks");
*      client.setBookmarkStore(bs);
*
*      client.connectAndLogon();
*
*      // create the object to process the messages.
*      BookmarkMessageHandler bmh = new BookmarkMessageHandler(client);
*
*      System.out.println("... entering subscription ...");
*
*      // Enter the subscription. This statement requests all
*      // messages that have not been previously processed on the
*      // "messages-history" topic.
*
*      client.executeAsync( new Command(Message.Command.Subscribe)
*                             .setTopic("messages-history")
*                             .setSubId(new CommandId("sample-replay-id"))
*                             .setBookmark(Client.Bookmarks.MOST_RECENT),
*                          bmh);
*
*      while (true)
*      {
*        Thread.sleep(100);
*      }
*
*    }
*    catch (AMPSException e) {
*      System.err.println(e.getLocalizedMessage());
*      e.printStackTrace(System.err);
*    }
* </code>
* </pre>
*/

public interface Subscription
{
    public long log(BookmarkField bookmark) throws java.io.IOException,CommandException;
    public void discard(long index) throws java.io.IOException;
    public boolean isDiscarded(BookmarkField bookmark) throws java.io.IOException;
    public Field getMostRecent();
    public Field getMostRecentList(boolean useList);
    public BookmarkRangeField getRange();
    @Deprecated
    public void setLastPersisted(long bookmark) throws java.io.IOException;
    public void setLastPersisted(BookmarkField bookmark) throws java.io.IOException;
    public long getOldestBookmarkSeq();
    public void setResizeHandler(BookmarkStoreResizeHandler handler, BookmarkStore store);

}
