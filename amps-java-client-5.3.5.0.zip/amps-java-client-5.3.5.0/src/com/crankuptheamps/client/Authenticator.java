////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.exception.AuthenticationException;

/**
 * Interface used by the AMPS Java Client to manage user authentication. This interface is
 * responsible for providing a password or token that will be sent to AMPS for authentication.
 *
 * Implementations of this interface can define how the client retrieves the password or token,
 * such as fetching single-use certificates, dynamic tokens, or other credentials.
 *
 * Implementations can throw an AuthenticationException to indicate failure at any point.
 *
 * Check the following link to view an example of the Authenticator.
 *
 * @see DefaultAuthenticator
 *
 * Kerberos implementations in this public repository can be used as examples for your own implementations.
 * @see <a href="https://github.com/60East/amps-authentication-java" >the public repository with examples</a>
 *
 */

public interface Authenticator
{
    /** Called by the AMPS.Client just before the logon command is sent to the server.
     *
     * This method allows the client to provide the password or token to be included in the
     * Password header field of the logon command. For example, this could fetch a
     * single-use certificate or token if required by the AMPS configuration.
     *
     * @param username_ The current value of the username, as specified in the URI.
     * @param currentPassword_ The current value of the password, as specified in the URI.
     * @return The password or token to include in the Password header field of the logon command.
     * @throws AuthenticationException If an error occurs while retrieving or generating the password.
     */
    public String authenticate(String username_, String currentPassword_) throws AuthenticationException;

    /** Called when the server responds to a logon attempt with a status of "retry".
     *
     * This method provides a mechanism for the client to update the password or token to use
     * for the next logon attempt. AMPS will continue retrying the logon as long as the server
     * indicates "retry".
     *
     * @param username_ The username returned by the server's ACK message.
     * @param password_ The password or token returned in the server's ACK message.
     * @return The updated password or token to include in the Password header for the next logon attempt.
     * @throws AuthenticationException If an error occurs while updating the password.
     */
    public String retry(String username_, String password_) throws AuthenticationException;

    /** Called when a logon completes successfully.
     *
     * This method notifies the authenticator that the logon was successful and provides the
     * username, password, and the reason for the successful logon. This can be used for
     * auditing, logging, or updating the state of the client application.
     *
     * @param username_ The username that successfully logged on to the server.
     * @param password_ The password that successfully logged on to the server.
     * @param reason_ The reason (a value from Message.Reason) for the successful completion of the logon.
     * @throws AuthenticationException If the client-side authentication module detects an error.
     */
    public void completed(String username_, String password_, int reason_) throws AuthenticationException;
}

