////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;

/**
 * ReconnectDelayStrategy implementations are called by HAClient to determine
 * how long to wait between attempts to connect or reconnect to a server.
 * The AMPS client provides two predefined implementations:
 * {@link ExponentialDelayStrategy} and {@link FixedDelayStrategy}.
 */
public interface ReconnectDelayStrategy {
    /**
     * Returns the time (in milliseconds) that the client should wait before
     * connecting to the given server URI.
     *
     * @param uri_ The URI to which the client plans to connect.
     * @return The time, in milliseconds, which the client should delay
     *         before connecting to uri_.
     *
     * @throws Exception Any exception thrown indicates no connection
     *                   should be attempted; the client in essence
     *                   should "give up."
     */
    int getConnectWaitDuration(String uri_) throws Exception;

    /**
     * Reset the state of this reconnect delay. AMPS calls this method when
     * a connection is successfully established.
     */
    void reset();
}
