///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import com.crankuptheamps.client.fields.BookmarkField;
import com.crankuptheamps.client.fields.Field;

/**
 * This class is responsible for creating recovery points.
 * It implements the RecoveryPointFactory interface and is used to generate
 * instances of DynamicRecoveryPoint. The factory uses a `BookmarkStore` and a
 * subscription identifier (`subId`) to create these recovery points.
 */
class DynamicRecoveryPointFactory implements RecoveryPointFactory {
    private BookmarkStore _store;

    /**
     * Constructor for DynamicRecoveryPointFactory.
     *
     * @param store_ A BookmarkStore instance that is used to create recovery
     *               points.
     */
    public DynamicRecoveryPointFactory(BookmarkStore store_) {
        _store = store_;
    }

    /**
     * Creates a new RecoveryPoint based on the provided subId and bookmark.
     *
     * @param subId_    The Field representing the subscription identifier.
     * @param bookmark_ The BookmarkField representing the bookmark for recovery.
     * @return A new DynamicRecoveryPoint instance with the provided store and
     *         subId.
     */
    public RecoveryPoint createRecoveryPoint(Field subId_, BookmarkField bookmark_) {
        return new DynamicRecoveryPoint(_store, subId_);
    }
}
