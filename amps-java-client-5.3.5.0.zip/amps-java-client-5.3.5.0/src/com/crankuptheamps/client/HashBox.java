////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;
import java.util.*;

/**
 * A helper class, used as a HashMap key, that can hash strings, byte array regions, or integers.
 */
public class HashBox
{
  
  public HashBox()
  {
  }
  
  public HashBox set(String stringValue_)
  {
    _hash = stringValue_.hashCode();

    return this;
  }

  public HashBox set(byte[] array_, int offset_, int length_)
  {
    if(offset_ == 0 && length_ == array_.length)
    {
      _hash = Arrays.hashCode(array_);
    }
    else
    {
      if(_bytes == null || _bytes.length != length_)
        _bytes = new byte[length_];
      System.arraycopy(array_,offset_,_bytes,0,length_);
      _hash = Arrays.hashCode(_bytes);
    }
    return this;
  }

  public HashBox set(int hashValue_)
  {
    _hash = hashValue_;
    return this;
  }

  public int hashCode()
  {
    return _hash;
  }

  public HashBox clone()
  {
    HashBox box = new HashBox();
    box._hash = _hash;
    return box;
  }

  public boolean equals(Object o)
  {
    if (o == null) return false;
    return _hash == o.hashCode();
  }

  private int _hash;
  private byte[] _bytes;
}
