////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

import java.net.Socket;
import java.net.URI;
import java.nio.ByteBuffer;
import java.beans.ExceptionListener;
import java.util.Properties;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.net.ssl.*;
import java.security.*;

import com.crankuptheamps.client.Message.SerializationResult;
import com.crankuptheamps.client.exception.AlreadyConnectedException;
import com.crankuptheamps.client.exception.ConnectionRefusedException;
import com.crankuptheamps.client.exception.DisconnectedException;
import com.crankuptheamps.client.exception.InvalidURIException;
import com.crankuptheamps.client.exception.RetryOperationException;

/**
 * Implements an AMPS transport over SSL.
 * Use this transport by connecting to URIs beginning with {@code tcps://}.
 * Use the methods on this class to customize SSL settings prior to connecting.
 */
public class TCPSTransport extends TCPTransport
{
    private static volatile SSLContext _defaultSSLContext = null;
    private static String[]   _suites = null;
    private static String[]   _protocols = null;

    protected TCPSTransportImpl constructTransportImpl(Protocol protocol, Properties properties)
    {
        return new TCPSTransportImpl(protocol, properties, new DefaultTransportFilter());
    }
    public TCPSTransport(Protocol protocol, Properties properties)
    {
        super(protocol,properties);
    }

    public TCPSTransport(Protocol msgType)
    {
       super(msgType);
    }

    public TCPSTransport(Protocol msgType, TCPSTransportImpl impl)
    {
       super(msgType, impl);
    }

    /**
     * Sets the default SSL Context used for new connections.
     *
     * @param sslContext The default SSL context object. This context
     * must be initialized before calling.
     */
    public static void setDefaultSSLContext(SSLContext sslContext)
    {
        TCPSTransport._defaultSSLContext = sslContext;
    }

    /**
     * Returns the SSL context that will be used for connecting.
     *
     * @return The current default SSL context object.
     * @throws NoSuchAlgorithmException Propagates this exception when it is thrown by an attempt to get the default SSLContext.
     */
    public static SSLContext getDefaultSSLContext() throws NoSuchAlgorithmException
    {
       if(TCPSTransport._defaultSSLContext == null)
       {
          TCPSTransport._defaultSSLContext = SSLContext.getDefault();
       }
       return TCPSTransport._defaultSSLContext;
    }


    /**
     * Sets the cipher suites that will be enabled on SSLSockets.
     *
     * This string array will be passed to
     * {@link javax.net.ssl.SSLSocket#setEnabledCipherSuites} whenever a
     * socket is created.
     *
     * @param suites The cipher suites to enable for new sockets.
     */
    public static void setDefaultEnabledCipherSuites(String[] suites)
    {
        _suites = new String[suites.length];
        System.arraycopy(suites, 0, _suites, 0, suites.length);
    }

    /**
     * Returns the cipher suites that will be enabled on SSLSockets.
     *
     * This function returns {@code null} if
     * {@link #setDefaultEnabledCipherSuites} has not been called.
     *
     * @return The cipher suites which will be enabled for new sockets,
     *   or {@code null} if the virtual machine's defaults will be used.
     */
    public static String[] getDefaultEnabledCipherSuites()
    {
        return _suites;
    }
    
    /**
     * Sets the protocols that will be enabled on SSLSockets.
     *
     * This string array will be passed to
     * {@link javax.net.ssl.SSLSocket#setEnabledProtocols} whenever a
     * socket is created.
     *
     * @param protocols The protocols to enable for new sockets.
     */
    public static void setDefaultEnabledProtocols(String[] protocols)
    {
        _protocols = new String[protocols.length];
        System.arraycopy(protocols, 0, _protocols, 0, protocols.length);
    }

    /**
     * Returns the protocols that will be enabled on SSLSockets.
     *
     * This function returns {@code null} if
     * {@link #setDefaultEnabledProtocols} has not been called.
     *
     * @return The protocols which will be enabled for new sockets,
     *   or {@code null} if the virtual machine's defaults will be used.
     */
    public static String[] getDefaultEnabledProtocols()
    {
        return _protocols;
    }
}
