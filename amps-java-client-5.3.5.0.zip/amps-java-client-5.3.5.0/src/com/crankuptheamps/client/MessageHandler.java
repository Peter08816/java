////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////

package com.crankuptheamps.client;

/**
 * Interface for all classes that handle AMPS messages.
 *
 * Example Usage:
 * <pre>
 * <code>
 *
 * public class MessagePrinter implements MessageHandler {
 *      public void invoke(Message m) {
 *          System.out.println(m.getData());
 *      }
 * }
 *
 * </code>
 * </pre>
 */

public interface MessageHandler
{
    /**
     * Method for the AMPS client to call when a message is received
     * <p>
     * The AMPS client reuses the same message object in successive calls to
     * the message handler, resetting the contents of the object for each call.
     * Should you need to use the data in the message outside of the call to
     * the message handler, you must copy the message object or copy data out
     * of the message object.
     * @param message the message received from AMPS. As mentioned above, this message object is
     * reused by successive calls to the handler.
     */
     
    public void invoke(Message message);
}
