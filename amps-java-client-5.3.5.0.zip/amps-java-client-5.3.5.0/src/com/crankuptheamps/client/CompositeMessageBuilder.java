////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2010-2025 60East Technologies Inc., All Rights Reserved.
//
// This computer software is owned by 60East Technologies Inc. and is
// protected by U.S. copyright laws and other laws and by international
// treaties.  This computer software is furnished by 60East Technologies
// Inc. pursuant to a written license agreement and may be used, copied,
// transmitted, and stored only in accordance with the terms of such
// license agreement and with the inclusion of the above copyright notice.
// This computer software or any other copies thereof may not be provided
// or otherwise made available to any other person.
//
// U.S. Government Restricted Rights.  This computer software: (a) was
// developed at private expense and is in all respects the proprietary
// information of 60East Technologies Inc.; (b) was not developed with
// government funds; (c) is a trade secret of 60East Technologies Inc.
// for all purposes of the Freedom of Information Act; and (d) is a
// commercial item and thus, pursuant to Section 12.212 of the Federal
// Acquisition Regulations (FAR) and DFAR Supplement Section 227.7202,
// Government's use, duplication or disclosure of the computer software
// is subject to the restrictions set forth by 60East Technologies Inc..
//
////////////////////////////////////////////////////////////////////////////
package com.crankuptheamps.client;

import java.io.PrintStream;

import com.crankuptheamps.client.fields.Field;

/**
 * Used to create payloads for AMPS composite messages, which are messages with
 * a number of parts where each part is a complete message of a specific
 * message type.
 * For example, a composite message type of "composite-json-binary" may be
 * declared on the server that combines a set of JSON headers with
 * an opaque binary payload. CompositeMessageBuilder makes it easy to assemble
 * this payload.
 * 
 */
public class CompositeMessageBuilder
{
    /**
     * Create a new, empty CompositeMessageBuilder.
     */
    public CompositeMessageBuilder()
    {
        _bytes = new byte[DEFAULT_INITIAL_CAPACITY];
        _position = 0;
    }
    
    /**
     * Create a new empty CompositeMessageBuilder.
     * @param initialCapacity_ The default capacity in bytes for the serialized
     * representation of a message. Ideal value is total message size in
     * bytes + ( 4 * number of message parts).
     */
    public CompositeMessageBuilder(int initialCapacity_)
    {
        _bytes = new byte[initialCapacity_];
        _position = 0;
    }
    
    /**
     * Clears this object. Does not release or resize internal buffer.
     * @return This object
     */
    public CompositeMessageBuilder clear()
    {
        _position = 0;
        return this;
    }
    
    /**
     * Appends a byte array to this object.
     * @param data_ The bytes of the data to append.
     * @param offset_ The offset in data_ where your data begins.
     * @param length_ The length of your data.
     * @return This object
     */
    public CompositeMessageBuilder append(byte[] data_, int offset_, int length_)
    {        
        if(_bytes.length < _position + length_ + HEADER_LENGTH)
        {
            _resizeToAtLeast(_position + length_ + HEADER_LENGTH);
        }
        _writeHeader(length_);
        _write(data_,offset_,length_);
        return this;
    }

    /**
     * Appends a message part to this object.
     * @param data_ The data to append.
     * @return This object
     */
    public CompositeMessageBuilder append(String data_)
    {
        byte[] buf = data_.getBytes();
        return append(buf,0,buf.length);
    }
    
    /**
     * Sets a Field with the contents of this object.
     * @param field_ The Field to set.
     */
    public void setField(Field field_)
    {
        field_.buffer = _bytes;
        field_.length = _position;
        field_.position = 0;
    }
    
    // Private methods //
    private void _write(byte[] data_, int offset_, int length_)
    {
        if(length_ > 0)
        {
            System.arraycopy(data_,offset_,_bytes,_position,length_);
            _position += length_;
        }
    }
    private void _writeHeader(int length_)
    {
        _bytes[_position++] = (byte)((length_ & 0xFF000000) >> 24);
        _bytes[_position++] = (byte)((length_ & 0xFF0000) >> 16);
        _bytes[_position++] = (byte)((length_ & 0xFF00) >> 8);
        _bytes[_position++] = (byte)( length_ & 0xFF);
    }
    private void _resizeToAtLeast(int newSize_)
    {
        byte[] newData = new byte[(int)(newSize_ * 1.5)];
        System.arraycopy(_bytes,0,newData,0,_position);
        _bytes = newData;
    }
    private static int DEFAULT_INITIAL_CAPACITY = 16384;
    private static int HEADER_LENGTH = 4;
    
    public byte _bytes[] = null;
    public int  _position = 0;

}
